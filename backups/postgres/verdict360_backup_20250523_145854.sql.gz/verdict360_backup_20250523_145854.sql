--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

-- Started on 2025-05-23 12:58:54 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "Verdict360_legal";
--
-- TOC entry 3430 (class 1262 OID 16384)
-- Name: Verdict360_legal; Type: DATABASE; Schema: -; Owner: Verdict360
--

CREATE DATABASE "Verdict360_legal" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "Verdict360_legal" OWNER TO "Verdict360";

\connect "Verdict360_legal"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 24666)
-- Name: document_templates; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.document_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(100) NOT NULL,
    template_content text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.document_templates OWNER TO "Verdict360";

--
-- TOC entry 219 (class 1259 OID 24608)
-- Name: documents; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    file_path character varying(512) NOT NULL,
    file_type character varying(100) NOT NULL,
    matter_id integer,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.documents OWNER TO "Verdict360";

--
-- TOC entry 218 (class 1259 OID 24607)
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO "Verdict360";

--
-- TOC entry 3431 (class 0 OID 0)
-- Dependencies: 218
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- TOC entry 217 (class 1259 OID 24592)
-- Name: matters; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.matters (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.matters OWNER TO "Verdict360";

--
-- TOC entry 216 (class 1259 OID 24591)
-- Name: matters_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.matters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matters_id_seq OWNER TO "Verdict360";

--
-- TOC entry 3432 (class 0 OID 0)
-- Dependencies: 216
-- Name: matters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.matters_id_seq OWNED BY public.matters.id;


--
-- TOC entry 221 (class 1259 OID 24629)
-- Name: recordings; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.recordings (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    file_path character varying(512) NOT NULL,
    duration integer,
    matter_id integer,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.recordings OWNER TO "Verdict360";

--
-- TOC entry 220 (class 1259 OID 24628)
-- Name: recordings_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.recordings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recordings_id_seq OWNER TO "Verdict360";

--
-- TOC entry 3433 (class 0 OID 0)
-- Dependencies: 220
-- Name: recordings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.recordings_id_seq OWNED BY public.recordings.id;


--
-- TOC entry 225 (class 1259 OID 24675)
-- Name: system_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.system_config (
    key character varying(255) NOT NULL,
    value text,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.system_config OWNER TO "Verdict360";

--
-- TOC entry 223 (class 1259 OID 24650)
-- Name: transcriptions; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.transcriptions (
    id integer NOT NULL,
    recording_id integer,
    text text NOT NULL,
    language character varying(50) DEFAULT 'en'::character varying,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transcriptions OWNER TO "Verdict360";

--
-- TOC entry 222 (class 1259 OID 24649)
-- Name: transcriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.transcriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transcriptions_id_seq OWNER TO "Verdict360";

--
-- TOC entry 3434 (class 0 OID 0)
-- Dependencies: 222
-- Name: transcriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.transcriptions_id_seq OWNED BY public.transcriptions.id;


--
-- TOC entry 215 (class 1259 OID 24577)
-- Name: users; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    role character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO "Verdict360";

--
-- TOC entry 214 (class 1259 OID 24576)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "Verdict360";

--
-- TOC entry 3435 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3233 (class 2604 OID 24611)
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- TOC entry 3230 (class 2604 OID 24595)
-- Name: matters id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.matters ALTER COLUMN id SET DEFAULT nextval('public.matters_id_seq'::regclass);


--
-- TOC entry 3236 (class 2604 OID 24632)
-- Name: recordings id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.recordings ALTER COLUMN id SET DEFAULT nextval('public.recordings_id_seq'::regclass);


--
-- TOC entry 3239 (class 2604 OID 24653)
-- Name: transcriptions id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.transcriptions ALTER COLUMN id SET DEFAULT nextval('public.transcriptions_id_seq'::regclass);


--
-- TOC entry 3227 (class 2604 OID 24580)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3423 (class 0 OID 24666)
-- Dependencies: 224
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.document_templates (id, name, document_type, template_content, created_at) FROM stdin;
d1b6dc66-8066-4dd7-b414-5ecb6623f477	Contract of Sale Template	contract	This is a template for a basic contract of sale under South African law...	2025-05-23 12:56:54.165957+00
9d8e2071-f053-420a-bfa7-da34b7402fd1	Employment Contract Template	contract	Standard employment contract template compliant with Labour Relations Act...	2025-05-23 12:56:54.165957+00
ecfd14bd-5a96-460e-ac59-9d41ca74de7a	Legal Opinion Template	opinion	Template for legal opinion documents with proper South African legal structure...	2025-05-23 12:56:54.165957+00
c656c61a-97d1-492f-8ed0-0240c8537939	Pleading Template	pleading	Standard pleading template for South African court proceedings...	2025-05-23 12:56:54.165957+00
cbf95c5a-c0e3-496d-844a-c000614a1d9e	Contract of Sale Template	contract	This is a template for a basic contract of sale under South African law...	2025-05-23 12:58:21.541995+00
28f032b7-1bfc-40b0-b236-624805e1b825	Employment Contract Template	contract	Standard employment contract template compliant with Labour Relations Act...	2025-05-23 12:58:21.541995+00
fed8f23f-032f-4009-910c-0f0ddc8bb303	Legal Opinion Template	opinion	Template for legal opinion documents with proper South African legal structure...	2025-05-23 12:58:21.541995+00
b75e3829-79e1-4168-97b2-a2993035eb46	Pleading Template	pleading	Standard pleading template for South African court proceedings...	2025-05-23 12:58:21.541995+00
2c264a97-7f3a-4d7e-872b-e0e7e378f3c3	Contract of Sale Template	contract	This is a template for a basic contract of sale under South African law...	2025-05-23 12:58:48.16272+00
af1ddb8d-46f4-4043-8300-1a034592327e	Employment Contract Template	contract	Standard employment contract template compliant with Labour Relations Act...	2025-05-23 12:58:48.16272+00
75a2329d-fe4e-476b-9f6a-88e122465074	Legal Opinion Template	opinion	Template for legal opinion documents with proper South African legal structure...	2025-05-23 12:58:48.16272+00
07072125-545f-40ac-9032-71b4bb7390ff	Pleading Template	pleading	Standard pleading template for South African court proceedings...	2025-05-23 12:58:48.16272+00
\.


--
-- TOC entry 3418 (class 0 OID 24608)
-- Dependencies: 219
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.documents (id, title, description, file_path, file_type, matter_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3416 (class 0 OID 24592)
-- Dependencies: 217
-- Data for Name: matters; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.matters (id, title, description, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3420 (class 0 OID 24629)
-- Dependencies: 221
-- Data for Name: recordings; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.recordings (id, title, description, file_path, duration, matter_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3424 (class 0 OID 24675)
-- Dependencies: 225
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.system_config (key, value, description, created_at, updated_at) FROM stdin;
default_jurisdiction	South Africa	Default jurisdiction for legal documents	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
firm_name	Example Legal Firm	Default firm name for development	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
currency	ZAR	Default currency (South African Rand)	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
date_format	DD/MM/YYYY	Default date format for South African locale	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
max_upload_size	20971520	Maximum file upload size in bytes (20MB)	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
retention_period_years	7	Default document retention period in years	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
backup_frequency_hours	24	Backup frequency in hours	2025-05-23 12:56:54.169423+00	2025-05-23 12:58:48.165191+00
\.


--
-- TOC entry 3422 (class 0 OID 24650)
-- Dependencies: 223
-- Data for Name: transcriptions; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.transcriptions (id, recording_id, text, language, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3414 (class 0 OID 24577)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.users (id, username, email, first_name, last_name, role, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3436 (class 0 OID 0)
-- Dependencies: 218
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- TOC entry 3437 (class 0 OID 0)
-- Dependencies: 216
-- Name: matters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.matters_id_seq', 1, false);


--
-- TOC entry 3438 (class 0 OID 0)
-- Dependencies: 220
-- Name: recordings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.recordings_id_seq', 1, false);


--
-- TOC entry 3439 (class 0 OID 0)
-- Dependencies: 222
-- Name: transcriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.transcriptions_id_seq', 1, false);


--
-- TOC entry 3440 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- TOC entry 3262 (class 2606 OID 24674)
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3256 (class 2606 OID 24617)
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- TOC entry 3254 (class 2606 OID 24601)
-- Name: matters matters_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.matters
    ADD CONSTRAINT matters_pkey PRIMARY KEY (id);


--
-- TOC entry 3258 (class 2606 OID 24638)
-- Name: recordings recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.recordings
    ADD CONSTRAINT recordings_pkey PRIMARY KEY (id);


--
-- TOC entry 3264 (class 2606 OID 24683)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- TOC entry 3260 (class 2606 OID 24660)
-- Name: transcriptions transcriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.transcriptions
    ADD CONSTRAINT transcriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 3248 (class 2606 OID 24590)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3250 (class 2606 OID 24586)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3252 (class 2606 OID 24588)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3266 (class 2606 OID 24623)
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3267 (class 2606 OID 24618)
-- Name: documents documents_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES public.matters(id);


--
-- TOC entry 3265 (class 2606 OID 24602)
-- Name: matters matters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.matters
    ADD CONSTRAINT matters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3268 (class 2606 OID 24644)
-- Name: recordings recordings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.recordings
    ADD CONSTRAINT recordings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3269 (class 2606 OID 24639)
-- Name: recordings recordings_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.recordings
    ADD CONSTRAINT recordings_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES public.matters(id);


--
-- TOC entry 3270 (class 2606 OID 24661)
-- Name: transcriptions transcriptions_recording_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.transcriptions
    ADD CONSTRAINT transcriptions_recording_id_fkey FOREIGN KEY (recording_id) REFERENCES public.recordings(id);


-- Completed on 2025-05-23 12:58:54 UTC

--
-- PostgreSQL database dump complete
--

