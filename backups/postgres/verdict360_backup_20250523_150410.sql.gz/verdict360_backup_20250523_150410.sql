--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

-- Started on 2025-05-23 13:04:10 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "Verdict360_legal";
--
-- TOC entry 4371 (class 1262 OID 16384)
-- Name: Verdict360_legal; Type: DATABASE; Schema: -; Owner: Verdict360
--

CREATE DATABASE "Verdict360_legal" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "Verdict360_legal" OWNER TO "Verdict360";

\connect "Verdict360_legal"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 269 (class 1259 OID 25208)
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO "Verdict360";

--
-- TOC entry 298 (class 1259 OID 25651)
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO "Verdict360";

--
-- TOC entry 272 (class 1259 OID 25223)
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO "Verdict360";

--
-- TOC entry 271 (class 1259 OID 25218)
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO "Verdict360";

--
-- TOC entry 270 (class 1259 OID 25213)
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO "Verdict360";

--
-- TOC entry 273 (class 1259 OID 25228)
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO "Verdict360";

--
-- TOC entry 299 (class 1259 OID 25666)
-- Name: broker_link; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO "Verdict360";

--
-- TOC entry 227 (class 1259 OID 16500)
-- Name: case_law_references; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.case_law_references (
    id integer NOT NULL,
    citation character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    jurisdiction character varying(100) DEFAULT 'South Africa'::character varying NOT NULL,
    court character varying(100),
    year integer,
    document_id integer,
    summary text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    relevance_score double precision
);


ALTER TABLE public.case_law_references OWNER TO "Verdict360";

--
-- TOC entry 226 (class 1259 OID 16499)
-- Name: case_law_references_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.case_law_references_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_law_references_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4372 (class 0 OID 0)
-- Dependencies: 226
-- Name: case_law_references_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.case_law_references_id_seq OWNED BY public.case_law_references.id;


--
-- TOC entry 230 (class 1259 OID 24589)
-- Name: client; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO "Verdict360";

--
-- TOC entry 253 (class 1259 OID 24947)
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO "Verdict360";

--
-- TOC entry 310 (class 1259 OID 25915)
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO "Verdict360";

--
-- TOC entry 309 (class 1259 OID 25790)
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO "Verdict360";

--
-- TOC entry 255 (class 1259 OID 24957)
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO "Verdict360";

--
-- TOC entry 287 (class 1259 OID 25456)
-- Name: client_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO "Verdict360";

--
-- TOC entry 288 (class 1259 OID 25470)
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO "Verdict360";

--
-- TOC entry 311 (class 1259 OID 25956)
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO "Verdict360";

--
-- TOC entry 289 (class 1259 OID 25475)
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO "Verdict360";

--
-- TOC entry 231 (class 1259 OID 24600)
-- Name: client_session; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO "Verdict360";

--
-- TOC entry 276 (class 1259 OID 25246)
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO "Verdict360";

--
-- TOC entry 254 (class 1259 OID 24952)
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO "Verdict360";

--
-- TOC entry 268 (class 1259 OID 25130)
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO "Verdict360";

--
-- TOC entry 232 (class 1259 OID 24605)
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO "Verdict360";

--
-- TOC entry 277 (class 1259 OID 25327)
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO "Verdict360";

--
-- TOC entry 307 (class 1259 OID 25711)
-- Name: component; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO "Verdict360";

--
-- TOC entry 306 (class 1259 OID 25706)
-- Name: component_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


ALTER TABLE public.component_config OWNER TO "Verdict360";

--
-- TOC entry 233 (class 1259 OID 24608)
-- Name: composite_role; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO "Verdict360";

--
-- TOC entry 234 (class 1259 OID 24611)
-- Name: credential; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO "Verdict360";

--
-- TOC entry 229 (class 1259 OID 24581)
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO "Verdict360";

--
-- TOC entry 228 (class 1259 OID 24576)
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO "Verdict360";

--
-- TOC entry 312 (class 1259 OID 25972)
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO "Verdict360";

--
-- TOC entry 225 (class 1259 OID 16485)
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.document_chunks (
    id integer NOT NULL,
    document_id integer,
    chunk_index integer NOT NULL,
    content text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_chunks OWNER TO "Verdict360";

--
-- TOC entry 224 (class 1259 OID 16484)
-- Name: document_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.document_chunks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_chunks_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4373 (class 0 OID 0)
-- Dependencies: 224
-- Name: document_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.document_chunks_id_seq OWNED BY public.document_chunks.id;


--
-- TOC entry 321 (class 1259 OID 26151)
-- Name: document_templates; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.document_templates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    document_type character varying(100) NOT NULL,
    template_content text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_templates OWNER TO "Verdict360";

--
-- TOC entry 320 (class 1259 OID 26150)
-- Name: document_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.document_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_templates_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4374 (class 0 OID 0)
-- Dependencies: 320
-- Name: document_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.document_templates_id_seq OWNED BY public.document_templates.id;


--
-- TOC entry 235 (class 1259 OID 24616)
-- Name: event_entity; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.event_entity OWNER TO "Verdict360";

--
-- TOC entry 300 (class 1259 OID 25671)
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO "Verdict360";

--
-- TOC entry 301 (class 1259 OID 25676)
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO "Verdict360";

--
-- TOC entry 314 (class 1259 OID 25998)
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO "Verdict360";

--
-- TOC entry 302 (class 1259 OID 25685)
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO "Verdict360";

--
-- TOC entry 303 (class 1259 OID 25694)
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO "Verdict360";

--
-- TOC entry 304 (class 1259 OID 25697)
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO "Verdict360";

--
-- TOC entry 305 (class 1259 OID 25703)
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO "Verdict360";

--
-- TOC entry 258 (class 1259 OID 24993)
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO "Verdict360";

--
-- TOC entry 308 (class 1259 OID 25768)
-- Name: federated_user; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO "Verdict360";

--
-- TOC entry 284 (class 1259 OID 25395)
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO "Verdict360";

--
-- TOC entry 283 (class 1259 OID 25392)
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO "Verdict360";

--
-- TOC entry 259 (class 1259 OID 24998)
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO "Verdict360";

--
-- TOC entry 260 (class 1259 OID 25007)
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO "Verdict360";

--
-- TOC entry 265 (class 1259 OID 25111)
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO "Verdict360";

--
-- TOC entry 266 (class 1259 OID 25116)
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO "Verdict360";

--
-- TOC entry 282 (class 1259 OID 25389)
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO "Verdict360";

--
-- TOC entry 236 (class 1259 OID 24624)
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO "Verdict360";

--
-- TOC entry 219 (class 1259 OID 16423)
-- Name: legal_documents; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.legal_documents (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    document_type character varying(100) NOT NULL,
    jurisdiction character varying(100) DEFAULT 'South Africa'::character varying NOT NULL,
    matter_id integer,
    storage_path character varying(500) NOT NULL,
    file_type character varying(50) NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    confidentiality_level character varying(50) DEFAULT 'standard'::character varying NOT NULL
);


ALTER TABLE public.legal_documents OWNER TO "Verdict360";

--
-- TOC entry 218 (class 1259 OID 16422)
-- Name: legal_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.legal_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legal_documents_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4375 (class 0 OID 0)
-- Dependencies: 218
-- Name: legal_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.legal_documents_id_seq OWNED BY public.legal_documents.id;


--
-- TOC entry 217 (class 1259 OID 16401)
-- Name: legal_matters; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.legal_matters (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    reference_number character varying(100),
    client_id integer,
    practice_area character varying(100),
    responsible_attorney integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL
);


ALTER TABLE public.legal_matters OWNER TO "Verdict360";

--
-- TOC entry 216 (class 1259 OID 16400)
-- Name: legal_matters_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.legal_matters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legal_matters_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4376 (class 0 OID 0)
-- Dependencies: 216
-- Name: legal_matters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.legal_matters_id_seq OWNED BY public.legal_matters.id;


--
-- TOC entry 221 (class 1259 OID 16446)
-- Name: legal_recordings; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.legal_recordings (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    matter_id integer,
    storage_path character varying(500) NOT NULL,
    duration_seconds integer,
    transcription_status character varying(50) DEFAULT 'pending'::character varying,
    transcription_path character varying(500),
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    recording_date timestamp with time zone
);


ALTER TABLE public.legal_recordings OWNER TO "Verdict360";

--
-- TOC entry 220 (class 1259 OID 16445)
-- Name: legal_recordings_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.legal_recordings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legal_recordings_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4377 (class 0 OID 0)
-- Dependencies: 220
-- Name: legal_recordings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.legal_recordings_id_seq OWNED BY public.legal_recordings.id;


--
-- TOC entry 223 (class 1259 OID 16468)
-- Name: legal_transcriptions; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.legal_transcriptions (
    id integer NOT NULL,
    recording_id integer,
    text_content text NOT NULL,
    language character varying(50) DEFAULT 'en'::character varying,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.legal_transcriptions OWNER TO "Verdict360";

--
-- TOC entry 222 (class 1259 OID 16467)
-- Name: legal_transcriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.legal_transcriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legal_transcriptions_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4378 (class 0 OID 0)
-- Dependencies: 222
-- Name: legal_transcriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.legal_transcriptions_id_seq OWNED BY public.legal_transcriptions.id;


--
-- TOC entry 215 (class 1259 OID 16386)
-- Name: legal_users; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.legal_users (
    id integer NOT NULL,
    keycloak_id character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    firm_name character varying(255),
    role character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.legal_users OWNER TO "Verdict360";

--
-- TOC entry 214 (class 1259 OID 16385)
-- Name: legal_users_id_seq; Type: SEQUENCE; Schema: public; Owner: Verdict360
--

CREATE SEQUENCE public.legal_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legal_users_id_seq OWNER TO "Verdict360";

--
-- TOC entry 4379 (class 0 OID 0)
-- Dependencies: 214
-- Name: legal_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Verdict360
--

ALTER SEQUENCE public.legal_users_id_seq OWNED BY public.legal_users.id;


--
-- TOC entry 264 (class 1259 OID 25108)
-- Name: migration_model; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO "Verdict360";

--
-- TOC entry 281 (class 1259 OID 25380)
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO "Verdict360";

--
-- TOC entry 280 (class 1259 OID 25375)
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO "Verdict360";

--
-- TOC entry 294 (class 1259 OID 25594)
-- Name: policy_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO "Verdict360";

--
-- TOC entry 256 (class 1259 OID 24982)
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO "Verdict360";

--
-- TOC entry 257 (class 1259 OID 24988)
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO "Verdict360";

--
-- TOC entry 237 (class 1259 OID 24630)
-- Name: realm; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO "Verdict360";

--
-- TOC entry 238 (class 1259 OID 24647)
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO "Verdict360";

--
-- TOC entry 286 (class 1259 OID 25404)
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO "Verdict360";

--
-- TOC entry 263 (class 1259 OID 25100)
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO "Verdict360";

--
-- TOC entry 239 (class 1259 OID 24655)
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO "Verdict360";

--
-- TOC entry 319 (class 1259 OID 26106)
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO "Verdict360";

--
-- TOC entry 240 (class 1259 OID 24658)
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO "Verdict360";

--
-- TOC entry 241 (class 1259 OID 24665)
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO "Verdict360";

--
-- TOC entry 261 (class 1259 OID 25016)
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO "Verdict360";

--
-- TOC entry 242 (class 1259 OID 24675)
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO "Verdict360";

--
-- TOC entry 279 (class 1259 OID 25339)
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO "Verdict360";

--
-- TOC entry 278 (class 1259 OID 25332)
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO "Verdict360";

--
-- TOC entry 316 (class 1259 OID 26037)
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO "Verdict360";

--
-- TOC entry 296 (class 1259 OID 25621)
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO "Verdict360";

--
-- TOC entry 295 (class 1259 OID 25606)
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO "Verdict360";

--
-- TOC entry 290 (class 1259 OID 25544)
-- Name: resource_server; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO "Verdict360";

--
-- TOC entry 315 (class 1259 OID 26013)
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO "Verdict360";

--
-- TOC entry 293 (class 1259 OID 25580)
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO "Verdict360";

--
-- TOC entry 291 (class 1259 OID 25552)
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO "Verdict360";

--
-- TOC entry 292 (class 1259 OID 25566)
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO "Verdict360";

--
-- TOC entry 317 (class 1259 OID 26055)
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO "Verdict360";

--
-- TOC entry 318 (class 1259 OID 26065)
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO "Verdict360";

--
-- TOC entry 243 (class 1259 OID 24678)
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO "Verdict360";

--
-- TOC entry 297 (class 1259 OID 25636)
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO "Verdict360";

--
-- TOC entry 322 (class 1259 OID 26160)
-- Name: system_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.system_config (
    key character varying(255) NOT NULL,
    value text,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_config OWNER TO "Verdict360";

--
-- TOC entry 245 (class 1259 OID 24684)
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO "Verdict360";

--
-- TOC entry 267 (class 1259 OID 25121)
-- Name: user_consent; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO "Verdict360";

--
-- TOC entry 313 (class 1259 OID 25988)
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO "Verdict360";

--
-- TOC entry 246 (class 1259 OID 24689)
-- Name: user_entity; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO "Verdict360";

--
-- TOC entry 247 (class 1259 OID 24697)
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO "Verdict360";

--
-- TOC entry 274 (class 1259 OID 25233)
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO "Verdict360";

--
-- TOC entry 275 (class 1259 OID 25238)
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO "Verdict360";

--
-- TOC entry 248 (class 1259 OID 24702)
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO "Verdict360";

--
-- TOC entry 285 (class 1259 OID 25401)
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO "Verdict360";

--
-- TOC entry 249 (class 1259 OID 24707)
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO "Verdict360";

--
-- TOC entry 250 (class 1259 OID 24710)
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO "Verdict360";

--
-- TOC entry 251 (class 1259 OID 24713)
-- Name: user_session; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO "Verdict360";

--
-- TOC entry 262 (class 1259 OID 25019)
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO "Verdict360";

--
-- TOC entry 244 (class 1259 OID 24681)
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO "Verdict360";

--
-- TOC entry 252 (class 1259 OID 24724)
-- Name: web_origins; Type: TABLE; Schema: public; Owner: Verdict360
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO "Verdict360";

--
-- TOC entry 3628 (class 2604 OID 16503)
-- Name: case_law_references id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.case_law_references ALTER COLUMN id SET DEFAULT nextval('public.case_law_references_id_seq'::regclass);


--
-- TOC entry 3626 (class 2604 OID 16488)
-- Name: document_chunks id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_chunks ALTER COLUMN id SET DEFAULT nextval('public.document_chunks_id_seq'::regclass);


--
-- TOC entry 3705 (class 2604 OID 26154)
-- Name: document_templates id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_templates ALTER COLUMN id SET DEFAULT nextval('public.document_templates_id_seq'::regclass);


--
-- TOC entry 3613 (class 2604 OID 16426)
-- Name: legal_documents id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_documents ALTER COLUMN id SET DEFAULT nextval('public.legal_documents_id_seq'::regclass);


--
-- TOC entry 3609 (class 2604 OID 16404)
-- Name: legal_matters id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_matters ALTER COLUMN id SET DEFAULT nextval('public.legal_matters_id_seq'::regclass);


--
-- TOC entry 3618 (class 2604 OID 16449)
-- Name: legal_recordings id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_recordings ALTER COLUMN id SET DEFAULT nextval('public.legal_recordings_id_seq'::regclass);


--
-- TOC entry 3622 (class 2604 OID 16471)
-- Name: legal_transcriptions id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_transcriptions ALTER COLUMN id SET DEFAULT nextval('public.legal_transcriptions_id_seq'::regclass);


--
-- TOC entry 3606 (class 2604 OID 16389)
-- Name: legal_users id; Type: DEFAULT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_users ALTER COLUMN id SET DEFAULT nextval('public.legal_users_id_seq'::regclass);


--
-- TOC entry 4312 (class 0 OID 25208)
-- Dependencies: 269
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- TOC entry 4341 (class 0 OID 25651)
-- Dependencies: 298
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- TOC entry 4315 (class 0 OID 25223)
-- Dependencies: 272
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
b7e0e638-f42a-4be0-a4bf-e2483b766a93	\N	auth-cookie	a23be480-b0a4-4877-a9da-504074063b45	da887d0d-b7a6-44a8-a808-95cf095ecba5	2	10	f	\N	\N
dc859a8b-7bca-4e51-9497-d554939895de	\N	auth-spnego	a23be480-b0a4-4877-a9da-504074063b45	da887d0d-b7a6-44a8-a808-95cf095ecba5	3	20	f	\N	\N
eb7aa0e1-1f94-4ed0-b1b6-b38c9785a712	\N	identity-provider-redirector	a23be480-b0a4-4877-a9da-504074063b45	da887d0d-b7a6-44a8-a808-95cf095ecba5	2	25	f	\N	\N
3d66c0de-cdee-4fd0-9999-01285cb51e58	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	da887d0d-b7a6-44a8-a808-95cf095ecba5	2	30	t	96885d98-7483-4964-9be7-fc765dd82486	\N
e3a5deed-92f0-42b7-8a79-5577c8a7aa0a	\N	auth-username-password-form	a23be480-b0a4-4877-a9da-504074063b45	96885d98-7483-4964-9be7-fc765dd82486	0	10	f	\N	\N
d861d343-7d49-4e59-900d-04315496a2fe	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	96885d98-7483-4964-9be7-fc765dd82486	1	20	t	94b7645c-ac91-44d7-8ac7-3bb81cc432bf	\N
6911dc61-7f0f-42fe-b77f-387b95881a03	\N	conditional-user-configured	a23be480-b0a4-4877-a9da-504074063b45	94b7645c-ac91-44d7-8ac7-3bb81cc432bf	0	10	f	\N	\N
3478e926-7add-43c8-af5f-fab52948082f	\N	auth-otp-form	a23be480-b0a4-4877-a9da-504074063b45	94b7645c-ac91-44d7-8ac7-3bb81cc432bf	0	20	f	\N	\N
e079ad30-7ff6-4c2f-b4f7-eeb8b15acb80	\N	direct-grant-validate-username	a23be480-b0a4-4877-a9da-504074063b45	d852cd57-804e-4d02-84a0-ee588b21d358	0	10	f	\N	\N
0f71b770-b46e-4483-a41a-18108624f974	\N	direct-grant-validate-password	a23be480-b0a4-4877-a9da-504074063b45	d852cd57-804e-4d02-84a0-ee588b21d358	0	20	f	\N	\N
4d7787d9-3d00-43fb-8539-6bf624158a04	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	d852cd57-804e-4d02-84a0-ee588b21d358	1	30	t	e898599f-347d-4049-8929-2bb24e3b1d92	\N
46316114-1cf5-423f-ae9b-5e82d3874991	\N	conditional-user-configured	a23be480-b0a4-4877-a9da-504074063b45	e898599f-347d-4049-8929-2bb24e3b1d92	0	10	f	\N	\N
a97c5470-2661-4aff-afd0-07d01660e75d	\N	direct-grant-validate-otp	a23be480-b0a4-4877-a9da-504074063b45	e898599f-347d-4049-8929-2bb24e3b1d92	0	20	f	\N	\N
032abe65-84f7-415d-9993-f27a6c43d237	\N	registration-page-form	a23be480-b0a4-4877-a9da-504074063b45	6d2d6791-437c-489c-a7f5-a7b59b1e3284	0	10	t	365edcdc-769d-493c-a854-3b89276ab1fc	\N
07caa6eb-36fb-4333-8bd8-932908ed2a68	\N	registration-user-creation	a23be480-b0a4-4877-a9da-504074063b45	365edcdc-769d-493c-a854-3b89276ab1fc	0	20	f	\N	\N
4962f7b5-8d29-41be-93bf-6cbee12adca4	\N	registration-profile-action	a23be480-b0a4-4877-a9da-504074063b45	365edcdc-769d-493c-a854-3b89276ab1fc	0	40	f	\N	\N
3f0d4a11-6237-491d-a107-393262a4b47c	\N	registration-password-action	a23be480-b0a4-4877-a9da-504074063b45	365edcdc-769d-493c-a854-3b89276ab1fc	0	50	f	\N	\N
38ae5b71-931d-47c0-8763-7a6931fa0035	\N	registration-recaptcha-action	a23be480-b0a4-4877-a9da-504074063b45	365edcdc-769d-493c-a854-3b89276ab1fc	3	60	f	\N	\N
a4ddbf43-5659-4663-937e-1cd3eccdef06	\N	reset-credentials-choose-user	a23be480-b0a4-4877-a9da-504074063b45	95228ca5-7b92-4900-a1d7-6640c9af224d	0	10	f	\N	\N
9d26de95-df65-4676-9e80-7ce17f682f75	\N	reset-credential-email	a23be480-b0a4-4877-a9da-504074063b45	95228ca5-7b92-4900-a1d7-6640c9af224d	0	20	f	\N	\N
43773bc0-e008-4860-a4e6-99037a4beecf	\N	reset-password	a23be480-b0a4-4877-a9da-504074063b45	95228ca5-7b92-4900-a1d7-6640c9af224d	0	30	f	\N	\N
9d00f3db-7790-4afa-95ad-b8235f34e8f4	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	95228ca5-7b92-4900-a1d7-6640c9af224d	1	40	t	1ed4b7af-0bef-4a8c-b438-ab0d93d95db2	\N
137d01d4-6957-4f9f-bf66-a8b17a75a52f	\N	conditional-user-configured	a23be480-b0a4-4877-a9da-504074063b45	1ed4b7af-0bef-4a8c-b438-ab0d93d95db2	0	10	f	\N	\N
93491224-15e9-4870-80a2-5dd627a519f7	\N	reset-otp	a23be480-b0a4-4877-a9da-504074063b45	1ed4b7af-0bef-4a8c-b438-ab0d93d95db2	0	20	f	\N	\N
1f65b0a3-1f83-43cd-961d-8e349c7546d2	\N	client-secret	a23be480-b0a4-4877-a9da-504074063b45	b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	2	10	f	\N	\N
de9d3329-f74a-44aa-a2e4-442f24892558	\N	client-jwt	a23be480-b0a4-4877-a9da-504074063b45	b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	2	20	f	\N	\N
f5e74015-002a-4577-b799-7177424b6339	\N	client-secret-jwt	a23be480-b0a4-4877-a9da-504074063b45	b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	2	30	f	\N	\N
a144d770-e2ab-4968-a55a-18d84e9b6969	\N	client-x509	a23be480-b0a4-4877-a9da-504074063b45	b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	2	40	f	\N	\N
65d9f788-d360-4045-8d92-4f38c21be396	\N	idp-review-profile	a23be480-b0a4-4877-a9da-504074063b45	866b8220-a2cf-48ce-a52d-dae8e42ee857	0	10	f	\N	26fd6394-b551-4387-9319-c3baabfc89c9
cc9838f4-0d0e-49a6-b221-18d9075156b4	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	866b8220-a2cf-48ce-a52d-dae8e42ee857	0	20	t	b54806ab-998b-473f-9fdb-abb4af7902cf	\N
c6a9e424-a3c7-4b5e-8229-d52a00859f62	\N	idp-create-user-if-unique	a23be480-b0a4-4877-a9da-504074063b45	b54806ab-998b-473f-9fdb-abb4af7902cf	2	10	f	\N	c92c4d10-b631-4fdb-8626-8bb9e69773f2
d8cd6ac8-0b2c-4cd3-8560-38a749e1f231	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	b54806ab-998b-473f-9fdb-abb4af7902cf	2	20	t	569e213e-67a8-42ee-954c-ededa20bc72e	\N
0f15fcc8-92de-4e53-8ea6-c4660b030582	\N	idp-confirm-link	a23be480-b0a4-4877-a9da-504074063b45	569e213e-67a8-42ee-954c-ededa20bc72e	0	10	f	\N	\N
575c5ba9-9fcc-4d5b-8417-8fb8bb27abe8	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	569e213e-67a8-42ee-954c-ededa20bc72e	0	20	t	9a95857f-8a36-47dd-9ad8-d5b4e081694e	\N
28ed8195-384d-446d-85dd-64f439b56767	\N	idp-email-verification	a23be480-b0a4-4877-a9da-504074063b45	9a95857f-8a36-47dd-9ad8-d5b4e081694e	2	10	f	\N	\N
fdc73c60-e1cc-4302-9ac3-01d811a2e8c6	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	9a95857f-8a36-47dd-9ad8-d5b4e081694e	2	20	t	f50373c8-5834-438d-a981-9f56fae29113	\N
a418218d-5380-4bd9-a8fd-e6734eef3adc	\N	idp-username-password-form	a23be480-b0a4-4877-a9da-504074063b45	f50373c8-5834-438d-a981-9f56fae29113	0	10	f	\N	\N
e27a1798-45cb-451a-9e09-e4fba6b95e40	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	f50373c8-5834-438d-a981-9f56fae29113	1	20	t	636dd891-46bb-45ce-84a0-53b5d972773f	\N
7c6bc0eb-cfb3-4a62-932a-ede71e323516	\N	conditional-user-configured	a23be480-b0a4-4877-a9da-504074063b45	636dd891-46bb-45ce-84a0-53b5d972773f	0	10	f	\N	\N
e88444b0-2256-48e6-8836-42681f1f1c6b	\N	auth-otp-form	a23be480-b0a4-4877-a9da-504074063b45	636dd891-46bb-45ce-84a0-53b5d972773f	0	20	f	\N	\N
d5cb5c19-a5d7-48fb-951e-255710b517fe	\N	http-basic-authenticator	a23be480-b0a4-4877-a9da-504074063b45	9ee8bb0c-2c3e-4f34-9259-b75f1a13c653	0	10	f	\N	\N
78cf1b30-13cd-4a7f-a562-490da02691b4	\N	docker-http-basic-authenticator	a23be480-b0a4-4877-a9da-504074063b45	5d7ee496-1013-4cbb-ad0b-9977dfcb1c5a	0	10	f	\N	\N
ca4a4a0e-0783-4556-8470-5909b1c1ead5	\N	no-cookie-redirect	a23be480-b0a4-4877-a9da-504074063b45	5ef80478-91e0-4129-9281-2af640c85ea4	0	10	f	\N	\N
5251fdc2-7a94-4f8e-a1a9-621f8d551562	\N	\N	a23be480-b0a4-4877-a9da-504074063b45	5ef80478-91e0-4129-9281-2af640c85ea4	0	20	t	5283fb78-8e4f-4706-8070-491e0e6edb95	\N
b38d1bd8-eb59-4303-8579-3dd11ca78054	\N	basic-auth	a23be480-b0a4-4877-a9da-504074063b45	5283fb78-8e4f-4706-8070-491e0e6edb95	0	10	f	\N	\N
09db7bf7-2384-4caf-9c93-fe67cf55e78e	\N	basic-auth-otp	a23be480-b0a4-4877-a9da-504074063b45	5283fb78-8e4f-4706-8070-491e0e6edb95	3	20	f	\N	\N
7bf834cb-9379-4808-aef2-5a869cb25c8a	\N	auth-spnego	a23be480-b0a4-4877-a9da-504074063b45	5283fb78-8e4f-4706-8070-491e0e6edb95	3	30	f	\N	\N
\.


--
-- TOC entry 4314 (class 0 OID 25218)
-- Dependencies: 271
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
da887d0d-b7a6-44a8-a808-95cf095ecba5	browser	browser based authentication	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
96885d98-7483-4964-9be7-fc765dd82486	forms	Username, password, otp and other auth forms.	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
94b7645c-ac91-44d7-8ac7-3bb81cc432bf	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
d852cd57-804e-4d02-84a0-ee588b21d358	direct grant	OpenID Connect Resource Owner Grant	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
e898599f-347d-4049-8929-2bb24e3b1d92	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
6d2d6791-437c-489c-a7f5-a7b59b1e3284	registration	registration flow	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
365edcdc-769d-493c-a854-3b89276ab1fc	registration form	registration form	a23be480-b0a4-4877-a9da-504074063b45	form-flow	f	t
95228ca5-7b92-4900-a1d7-6640c9af224d	reset credentials	Reset credentials for a user if they forgot their password or something	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
1ed4b7af-0bef-4a8c-b438-ab0d93d95db2	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	clients	Base authentication for clients	a23be480-b0a4-4877-a9da-504074063b45	client-flow	t	t
866b8220-a2cf-48ce-a52d-dae8e42ee857	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
b54806ab-998b-473f-9fdb-abb4af7902cf	User creation or linking	Flow for the existing/non-existing user alternatives	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
569e213e-67a8-42ee-954c-ededa20bc72e	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
9a95857f-8a36-47dd-9ad8-d5b4e081694e	Account verification options	Method with which to verity the existing account	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
f50373c8-5834-438d-a981-9f56fae29113	Verify Existing Account by Re-authentication	Reauthentication of existing account	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
636dd891-46bb-45ce-84a0-53b5d972773f	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
9ee8bb0c-2c3e-4f34-9259-b75f1a13c653	saml ecp	SAML ECP Profile Authentication Flow	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
5d7ee496-1013-4cbb-ad0b-9977dfcb1c5a	docker auth	Used by Docker clients to authenticate against the IDP	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
5ef80478-91e0-4129-9281-2af640c85ea4	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	t	t
5283fb78-8e4f-4706-8070-491e0e6edb95	Authentication Options	Authentication options.	a23be480-b0a4-4877-a9da-504074063b45	basic-flow	f	t
\.


--
-- TOC entry 4313 (class 0 OID 25213)
-- Dependencies: 270
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
26fd6394-b551-4387-9319-c3baabfc89c9	review profile config	a23be480-b0a4-4877-a9da-504074063b45
c92c4d10-b631-4fdb-8626-8bb9e69773f2	create unique user config	a23be480-b0a4-4877-a9da-504074063b45
\.


--
-- TOC entry 4316 (class 0 OID 25228)
-- Dependencies: 273
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
26fd6394-b551-4387-9319-c3baabfc89c9	missing	update.profile.on.first.login
c92c4d10-b631-4fdb-8626-8bb9e69773f2	false	require.password.update.after.registration
\.


--
-- TOC entry 4342 (class 0 OID 25666)
-- Dependencies: 299
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- TOC entry 4270 (class 0 OID 16500)
-- Dependencies: 227
-- Data for Name: case_law_references; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.case_law_references (id, citation, title, jurisdiction, court, year, document_id, summary, created_at, relevance_score) FROM stdin;
1	2019 (2) SA 343 (SCA)	Example Commercial Case v Another Company	South Africa	Supreme Court of Appeal	2019	\N	Leading case on commercial contract interpretation	2025-05-23 13:02:57.455444+00	\N
2	[2021] ZACC 13	Constitutional Rights Case	South Africa	Constitutional Court	2021	\N	Landmark constitutional interpretation case	2025-05-23 13:02:57.455444+00	\N
3	2020 (5) BCLR 123 (GP)	Labour Dispute Example	South Africa	Gauteng High Court	2020	\N	Employment law precedent	2025-05-23 13:02:57.455444+00	\N
4	2018 (3) SA 456 (WCC)	Property Law Case Study	South Africa	Western Cape High Court	2018	\N	Property transfer and ownership rights	2025-05-23 13:02:57.455444+00	\N
5	[2022] ZASCA 45	Corporate Governance Matter	South Africa	Supreme Court of Appeal	2022	\N	Directors duties and corporate responsibility	2025-05-23 13:02:57.455444+00	\N
\.


--
-- TOC entry 4273 (class 0 OID 24589)
-- Dependencies: 230
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	f	master-realm	0	f	\N	\N	t	\N	f	a23be480-b0a4-4877-a9da-504074063b45	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	a23be480-b0a4-4877-a9da-504074063b45	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
b2df536b-82df-4436-b196-58ba081f1c2c	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	a23be480-b0a4-4877-a9da-504074063b45	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
3ced503d-99ff-4fbc-8904-893f7d1a48c7	t	f	broker	0	f	\N	\N	t	\N	f	a23be480-b0a4-4877-a9da-504074063b45	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	a23be480-b0a4-4877-a9da-504074063b45	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
14143509-7173-4345-8619-dad0c62c4576	t	f	admin-cli	0	t	\N	\N	f	\N	f	a23be480-b0a4-4877-a9da-504074063b45	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
\.


--
-- TOC entry 4296 (class 0 OID 24947)
-- Dependencies: 253
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	post.logout.redirect.uris	+
b2df536b-82df-4436-b196-58ba081f1c2c	post.logout.redirect.uris	+
b2df536b-82df-4436-b196-58ba081f1c2c	pkce.code.challenge.method	S256
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	post.logout.redirect.uris	+
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	pkce.code.challenge.method	S256
\.


--
-- TOC entry 4353 (class 0 OID 25915)
-- Dependencies: 310
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- TOC entry 4352 (class 0 OID 25790)
-- Dependencies: 309
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- TOC entry 4298 (class 0 OID 24957)
-- Dependencies: 255
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- TOC entry 4330 (class 0 OID 25456)
-- Dependencies: 287
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
f2f7daa1-9bb7-409b-85b5-469fa73427dd	offline_access	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect built-in scope: offline_access	openid-connect
428404a4-d674-467d-8642-16f537671b1f	role_list	a23be480-b0a4-4877-a9da-504074063b45	SAML role list	saml
74a4d1e9-b862-4c8e-a486-9644ae60c399	profile	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect built-in scope: profile	openid-connect
6939ca24-2830-4a4f-99d8-6807571b3526	email	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect built-in scope: email	openid-connect
a81cb08c-0422-44a6-95ea-25add888df18	address	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect built-in scope: address	openid-connect
078edefc-5bd4-4565-ba6a-553b0fdda53d	phone	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect built-in scope: phone	openid-connect
8f5eb381-11b2-4420-9940-e56c99cb64c3	roles	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect scope for add user roles to the access token	openid-connect
8116a500-67ea-47cb-b5cd-c6792d293b70	web-origins	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect scope for add allowed web origins to the access token	openid-connect
f2391c60-1539-44f7-b843-29c9caef3b31	microprofile-jwt	a23be480-b0a4-4877-a9da-504074063b45	Microprofile - JWT built-in scope	openid-connect
f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	acr	a23be480-b0a4-4877-a9da-504074063b45	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
\.


--
-- TOC entry 4331 (class 0 OID 25470)
-- Dependencies: 288
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
f2f7daa1-9bb7-409b-85b5-469fa73427dd	true	display.on.consent.screen
f2f7daa1-9bb7-409b-85b5-469fa73427dd	${offlineAccessScopeConsentText}	consent.screen.text
428404a4-d674-467d-8642-16f537671b1f	true	display.on.consent.screen
428404a4-d674-467d-8642-16f537671b1f	${samlRoleListScopeConsentText}	consent.screen.text
74a4d1e9-b862-4c8e-a486-9644ae60c399	true	display.on.consent.screen
74a4d1e9-b862-4c8e-a486-9644ae60c399	${profileScopeConsentText}	consent.screen.text
74a4d1e9-b862-4c8e-a486-9644ae60c399	true	include.in.token.scope
6939ca24-2830-4a4f-99d8-6807571b3526	true	display.on.consent.screen
6939ca24-2830-4a4f-99d8-6807571b3526	${emailScopeConsentText}	consent.screen.text
6939ca24-2830-4a4f-99d8-6807571b3526	true	include.in.token.scope
a81cb08c-0422-44a6-95ea-25add888df18	true	display.on.consent.screen
a81cb08c-0422-44a6-95ea-25add888df18	${addressScopeConsentText}	consent.screen.text
a81cb08c-0422-44a6-95ea-25add888df18	true	include.in.token.scope
078edefc-5bd4-4565-ba6a-553b0fdda53d	true	display.on.consent.screen
078edefc-5bd4-4565-ba6a-553b0fdda53d	${phoneScopeConsentText}	consent.screen.text
078edefc-5bd4-4565-ba6a-553b0fdda53d	true	include.in.token.scope
8f5eb381-11b2-4420-9940-e56c99cb64c3	true	display.on.consent.screen
8f5eb381-11b2-4420-9940-e56c99cb64c3	${rolesScopeConsentText}	consent.screen.text
8f5eb381-11b2-4420-9940-e56c99cb64c3	false	include.in.token.scope
8116a500-67ea-47cb-b5cd-c6792d293b70	false	display.on.consent.screen
8116a500-67ea-47cb-b5cd-c6792d293b70		consent.screen.text
8116a500-67ea-47cb-b5cd-c6792d293b70	false	include.in.token.scope
f2391c60-1539-44f7-b843-29c9caef3b31	false	display.on.consent.screen
f2391c60-1539-44f7-b843-29c9caef3b31	true	include.in.token.scope
f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	false	display.on.consent.screen
f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	false	include.in.token.scope
\.


--
-- TOC entry 4354 (class 0 OID 25956)
-- Dependencies: 311
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	6939ca24-2830-4a4f-99d8-6807571b3526	t
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	8116a500-67ea-47cb-b5cd-c6792d293b70	t
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	f2391c60-1539-44f7-b843-29c9caef3b31	f
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	a81cb08c-0422-44a6-95ea-25add888df18	f
b2df536b-82df-4436-b196-58ba081f1c2c	6939ca24-2830-4a4f-99d8-6807571b3526	t
b2df536b-82df-4436-b196-58ba081f1c2c	8116a500-67ea-47cb-b5cd-c6792d293b70	t
b2df536b-82df-4436-b196-58ba081f1c2c	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
b2df536b-82df-4436-b196-58ba081f1c2c	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
b2df536b-82df-4436-b196-58ba081f1c2c	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
b2df536b-82df-4436-b196-58ba081f1c2c	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
b2df536b-82df-4436-b196-58ba081f1c2c	f2391c60-1539-44f7-b843-29c9caef3b31	f
b2df536b-82df-4436-b196-58ba081f1c2c	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
b2df536b-82df-4436-b196-58ba081f1c2c	a81cb08c-0422-44a6-95ea-25add888df18	f
14143509-7173-4345-8619-dad0c62c4576	6939ca24-2830-4a4f-99d8-6807571b3526	t
14143509-7173-4345-8619-dad0c62c4576	8116a500-67ea-47cb-b5cd-c6792d293b70	t
14143509-7173-4345-8619-dad0c62c4576	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
14143509-7173-4345-8619-dad0c62c4576	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
14143509-7173-4345-8619-dad0c62c4576	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
14143509-7173-4345-8619-dad0c62c4576	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
14143509-7173-4345-8619-dad0c62c4576	f2391c60-1539-44f7-b843-29c9caef3b31	f
14143509-7173-4345-8619-dad0c62c4576	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
14143509-7173-4345-8619-dad0c62c4576	a81cb08c-0422-44a6-95ea-25add888df18	f
3ced503d-99ff-4fbc-8904-893f7d1a48c7	6939ca24-2830-4a4f-99d8-6807571b3526	t
3ced503d-99ff-4fbc-8904-893f7d1a48c7	8116a500-67ea-47cb-b5cd-c6792d293b70	t
3ced503d-99ff-4fbc-8904-893f7d1a48c7	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
3ced503d-99ff-4fbc-8904-893f7d1a48c7	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
3ced503d-99ff-4fbc-8904-893f7d1a48c7	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
3ced503d-99ff-4fbc-8904-893f7d1a48c7	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
3ced503d-99ff-4fbc-8904-893f7d1a48c7	f2391c60-1539-44f7-b843-29c9caef3b31	f
3ced503d-99ff-4fbc-8904-893f7d1a48c7	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
3ced503d-99ff-4fbc-8904-893f7d1a48c7	a81cb08c-0422-44a6-95ea-25add888df18	f
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	6939ca24-2830-4a4f-99d8-6807571b3526	t
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	8116a500-67ea-47cb-b5cd-c6792d293b70	t
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	f2391c60-1539-44f7-b843-29c9caef3b31	f
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
662ea99a-a93e-44cd-9d0f-3a11d68cbee8	a81cb08c-0422-44a6-95ea-25add888df18	f
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	6939ca24-2830-4a4f-99d8-6807571b3526	t
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	8116a500-67ea-47cb-b5cd-c6792d293b70	t
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	f2391c60-1539-44f7-b843-29c9caef3b31	f
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	a81cb08c-0422-44a6-95ea-25add888df18	f
\.


--
-- TOC entry 4332 (class 0 OID 25475)
-- Dependencies: 289
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
f2f7daa1-9bb7-409b-85b5-469fa73427dd	6edb2213-95c4-4107-bf5f-43820704d291
\.


--
-- TOC entry 4274 (class 0 OID 24600)
-- Dependencies: 231
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- TOC entry 4319 (class 0 OID 25246)
-- Dependencies: 276
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- TOC entry 4297 (class 0 OID 24952)
-- Dependencies: 254
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- TOC entry 4311 (class 0 OID 25130)
-- Dependencies: 268
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- TOC entry 4275 (class 0 OID 24605)
-- Dependencies: 232
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- TOC entry 4320 (class 0 OID 25327)
-- Dependencies: 277
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- TOC entry 4350 (class 0 OID 25711)
-- Dependencies: 307
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
b8075116-684d-41ee-947d-37e3dde6668c	Trusted Hosts	a23be480-b0a4-4877-a9da-504074063b45	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
8b140f66-4ec1-4988-84a8-514242ae80a2	Consent Required	a23be480-b0a4-4877-a9da-504074063b45	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
23441c22-2798-46ec-827e-bc0802968794	Full Scope Disabled	a23be480-b0a4-4877-a9da-504074063b45	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
2abddc70-e8d6-4dbb-b794-1da83242080b	Max Clients Limit	a23be480-b0a4-4877-a9da-504074063b45	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
be8a97a7-fe79-4450-a6cf-868f7055ca3e	Allowed Protocol Mapper Types	a23be480-b0a4-4877-a9da-504074063b45	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
0cd19aab-4ed5-43ec-b32b-507fd45e06ab	Allowed Client Scopes	a23be480-b0a4-4877-a9da-504074063b45	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	anonymous
07ffc680-062d-4e8e-a30f-ac95d1c16d19	Allowed Protocol Mapper Types	a23be480-b0a4-4877-a9da-504074063b45	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	authenticated
ecd7e017-d41e-4840-8503-7b43a41d6c2f	Allowed Client Scopes	a23be480-b0a4-4877-a9da-504074063b45	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	a23be480-b0a4-4877-a9da-504074063b45	authenticated
20ba8cc7-715d-4400-ad02-a88795e5f815	rsa-generated	a23be480-b0a4-4877-a9da-504074063b45	rsa-generated	org.keycloak.keys.KeyProvider	a23be480-b0a4-4877-a9da-504074063b45	\N
5f363986-56ce-4e9d-8978-36d67007d96b	rsa-enc-generated	a23be480-b0a4-4877-a9da-504074063b45	rsa-enc-generated	org.keycloak.keys.KeyProvider	a23be480-b0a4-4877-a9da-504074063b45	\N
248425b8-a99f-487a-b602-1dc9d35bee8d	hmac-generated	a23be480-b0a4-4877-a9da-504074063b45	hmac-generated	org.keycloak.keys.KeyProvider	a23be480-b0a4-4877-a9da-504074063b45	\N
3f9c861a-57c4-44af-88b4-b3ee2f5474b4	aes-generated	a23be480-b0a4-4877-a9da-504074063b45	aes-generated	org.keycloak.keys.KeyProvider	a23be480-b0a4-4877-a9da-504074063b45	\N
\.


--
-- TOC entry 4349 (class 0 OID 25706)
-- Dependencies: 306
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
bb8e24c1-28de-413f-ad29-12b618f0dba7	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	saml-user-property-mapper
20a75ccb-4ff8-40be-87b1-6f94d312f41a	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
e33696e0-9948-437f-bd84-0c2dce45c5ff	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
4eeac739-49b3-4c9b-8936-bb920f105d7e	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	saml-role-list-mapper
c0d2c773-2ca4-4f24-b0fd-d87167c88d77	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	saml-user-attribute-mapper
b22b75bd-8205-458a-b019-f25f56731909	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
c4126997-3092-4b49-af0d-e498984d9bc0	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	oidc-address-mapper
bff47e6d-f0e4-40be-a5c1-6f9d790566d1	be8a97a7-fe79-4450-a6cf-868f7055ca3e	allowed-protocol-mapper-types	oidc-full-name-mapper
6469bbca-efa3-4c3e-820f-fc1cfef3f5f2	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	saml-user-property-mapper
62e9fdb1-9444-466b-8c4d-5eeb6ffb9c41	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	oidc-full-name-mapper
c76a8a39-b867-4519-a1ac-79585d448481	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
9931fd0d-bf6c-4473-a20a-bc118b88dc7b	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
24a514de-976c-4c47-8604-155b7d47a1c5	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
181ccea8-24ae-42ce-b243-fc3d27716ac6	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	saml-user-attribute-mapper
d93579a1-457d-4c55-9774-b09600985910	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	oidc-address-mapper
310f3ecb-0d27-446f-b3a7-567510e9b5d9	07ffc680-062d-4e8e-a30f-ac95d1c16d19	allowed-protocol-mapper-types	saml-role-list-mapper
d435df29-80f5-4898-b248-f09f84ee482b	ecd7e017-d41e-4840-8503-7b43a41d6c2f	allow-default-scopes	true
c7ad8cd3-eb0f-4df2-882e-b81c4c457df6	2abddc70-e8d6-4dbb-b794-1da83242080b	max-clients	200
66902c91-4557-4f08-9f9b-728555364a3d	0cd19aab-4ed5-43ec-b32b-507fd45e06ab	allow-default-scopes	true
2886fdc2-54e6-443a-b7f8-810d2d82cb2d	b8075116-684d-41ee-947d-37e3dde6668c	host-sending-registration-request-must-match	true
8f3f03ed-be7f-45ff-a127-82bae85e3960	b8075116-684d-41ee-947d-37e3dde6668c	client-uris-must-match	true
ab2df234-c08b-4ccd-96c8-7444cab9d4fa	5f363986-56ce-4e9d-8978-36d67007d96b	privateKey	MIIEpAIBAAKCAQEAyNhUw7WRGbKJt20TSceU73rxfk+CJOea8ynunWZdAg9091KuL2mhcA2ymXQEOATLLarfEhp/Kz/D97IiLXjTBd/jUIKQ2b2s9mfvEoyEHConrEquDPZufwQZAmSC2pJG00z9sCHmtzrrv5/Q1mjEgN34fOaCxzEnCadiG32LNTTh/AKLQ9FGcxapHR+/Hh7yGXX+sG0wyOjWD66fjBYDa0kCnr1Zq2SNn9Zxns7iBAmHB49zsVHF17TUUCp0bZRs9NyDw8Dy+ZP5IL7TLVJBwcLnIgf1RcOTukEkkzbjFUN20w6egUj1S8w0vxaSUqgOfVDkcQQ8b2zKl5rIDJeX6wIDAQABAoIBAAMzDwafGdSi93aokioWt9SozLgKZDRaTCmbfWWcf9bMkDxwYL34nM3AKhwvsPGDggkUM8GCEoyJ04FaoRjAV/w7+M8LhWsyjlLOjQxqmKAqO7+O4P7r3g6/7fYPy9XXhrFPBKuNnrNEiQTgct83hAnZf1/d/C9YJRsOQ43UjicmzUkxnsP5a/V8ib1mSTZqUraZvP2IVq8KHHUNeBkmysaS5QuMw5Qdn9lgQvtUM/ETswEUx8JzmME14wss6dUnDv7lIn/qxSRn+detp/CHmnDDey5VQ7Z47Y98MGg/1MmKBti3PtM3dCZfHreTzLuVDglk/h8UrT1B8lSGC5RqxaECgYEA5bEJGsBFn6Ch8BTJd/QgRYfvc/gugdlJIbS0RRIrz/b/U0CDeackyqNJEnyA3mqwTe08hi8mGv3z1uhUbAt0z/d7NFvBZh5dxiT1Qy7XPPdAVm1iD8nz9N2TILffW07cGT3MBt/dMhZPh9SLJZDe0hDQ+It6Uj2OXHZkbqZ033cCgYEA39l2/1NwNFTJQ9ZOxYVTuw37XMyERShRXEjZtBI3tJcwRsyeIn+KUHkXlS5GWJ5XPdDQRP3qJUIOagTIDcMCJs8/npi6oafvBu4ts7/Rld2n2dLx5odsjB/ty9dcLi6p9+I71sgYi9WLHwNt7GsImAW/y4LEr9nK6hdP02aKMC0CgYEA3gicvHdQ1lX5NJNjjck3yP72wiwPCQZ6Y1LDUGGYaJhjiJ68eUTRk/D0GiKwkFChzTKfZzb8pusGY6CCu073xHF/b8Wi1oxUKc5gKGmHNy/ryaBDQu/+G551MxOLnkBFE0FhkOOmd1yJ1MvpFo9MVdRbrWdm/0jx7P+lZjESmVECgYEAozOka5DEvJKYTmof8ig7nKQcAFNnmBhGATdn6b5ieLrFysiB/nroN7WhePVM+m0vA/WK8tIA9PsNEUS9KjNkDTGKm7GUWCncvjvGfEe8oTwClXATR1Sy0hKxR62TGmSRLRX3NKecJc8h6BGTAgwjLtr6M4D6r47lPviSDXm0BF0CgYB3wZ07CkXrbKZQdUlFrsxUcUkGFJkmH8Z5ScsmhdqPRALNzKKvJgfoGZFUZIAxgl+GcFUL4TyrSuQ+qktb/QEkSWZjijorQryrbnq0Xj2Tjq5wtBVcvlQXlMPNaFYrLjfg12K9CamjsMekfE4LxzZcCyKD622rbWqsQIaB3InrOw==
97d7e730-33bd-4d12-b1fe-946e2ee09561	5f363986-56ce-4e9d-8978-36d67007d96b	algorithm	RSA-OAEP
8b2868af-f76f-4fdf-920e-4b9a46bdcf2f	5f363986-56ce-4e9d-8978-36d67007d96b	keyUse	ENC
268c38ac-aa4e-4f95-8be8-241c8a0cef2a	5f363986-56ce-4e9d-8978-36d67007d96b	priority	100
892ac372-6a5a-4658-94e2-bb9c6cd68bc4	5f363986-56ce-4e9d-8978-36d67007d96b	certificate	MIICmzCCAYMCBgGW/T1MrjANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUwNTIzMTMwMTE1WhcNMzUwNTIzMTMwMjU1WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDI2FTDtZEZsom3bRNJx5TvevF+T4Ik55rzKe6dZl0CD3T3Uq4vaaFwDbKZdAQ4BMstqt8SGn8rP8P3siIteNMF3+NQgpDZvaz2Z+8SjIQcKiesSq4M9m5/BBkCZILakkbTTP2wIea3Ouu/n9DWaMSA3fh85oLHMScJp2IbfYs1NOH8AotD0UZzFqkdH78eHvIZdf6wbTDI6NYPrp+MFgNrSQKevVmrZI2f1nGezuIECYcHj3OxUcXXtNRQKnRtlGz03IPDwPL5k/kgvtMtUkHBwuciB/VFw5O6QSSTNuMVQ3bTDp6BSPVLzDS/FpJSqA59UORxBDxvbMqXmsgMl5frAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAKdK85hqcnOklz0znxVN+nvep/CaRp0Ue1foD8CrGb6gzgR3Hz/w7rD5y2XaIczulxN+TfnZtjy54qjqd8qZES/a+evMYP34MLwG87nNAAAWxrzpsK8hIoSSG+1Cyle3jrji/6OFpRbSwAiYk4FpjLYvdJPmzrn5QmBaxJ1poV6aLZiXeRilNzjOF141rlWkLFquDfNXbZM279vC7QdSR/qfHYQbPljmIHYPcRKf4KuKoIet7wQB9HXor/EM2Hsls9heS8r1RFbidqvRZSWvpxyUe4MgQkS2tbr3QwoXTXZdvP6oacQn77ZDZ7/oBhZnXQBHoglKVN5umxbIfkhqTc4=
ef6b9882-f4c6-4b8f-89e6-e4d65c2f1ece	248425b8-a99f-487a-b602-1dc9d35bee8d	priority	100
eeceec15-00b4-452e-bdb4-bf4c8941a69e	248425b8-a99f-487a-b602-1dc9d35bee8d	kid	ee62bb9a-bfc7-45bf-a4a5-03e5e6b7188f
976308ec-d61c-4957-8b38-98ed575de77a	248425b8-a99f-487a-b602-1dc9d35bee8d	secret	yuALr7ysg0UchXpHDBpBjMK2lWdzqp0EK1MU_wz1DI8_JgX5L86gG2mZvzRJLORjvFm4FXMo1WyWXfWeP99cxQ
9e7adcf5-b13c-450a-ba91-8d32c3b47a3e	248425b8-a99f-487a-b602-1dc9d35bee8d	algorithm	HS256
f7d05de7-3325-4643-98d9-8f9e1eeca9f2	20ba8cc7-715d-4400-ad02-a88795e5f815	privateKey	MIIEpAIBAAKCAQEAn4niLH5qLnmnetZap4dsQcB0LveTgdU84PTP06VrmPMVXfEfYyEsdSho+NrcV+UfVHH4c7odUVxc5Eb6qwCKOsiG532P3350ie1W966lUq/im5MOgXHatrdIKAvjI0bztbmb7Kx9MPg2mx/97SKP0XoCjCiCTPHR+hr5C1DLrjUPVPuVDDsfqFn7DtTwoQq35syZxoeIEHoO0Qw2SyQhP4GUy/DwvzlMPo1g7UUUyDGgtXskLUxO6b84cTus+hipBco9mhGEVsLaLc/YWD3cItz7xr4urS9kpATVzsQ6KkG+mOj6r87hu2w9qe2nuMslZZRqvcCLNn526/cxPS2bNQIDAQABAoIBADa2xwaTZD8EIdgS44xI+WujYTUqW0BPrU1JKG1hcgFGfLF3HFiW6/RSI44VITRTs+b2H0sxLRTWJFV1skorKTz3wKxrd4giij0zVHwlPTWadJD+Yh8quOOo/+ocCY3zq2lLepo0ncrJlZCl7CQDkmc4/N6sleNlm6m2zmp/DxtzNFG+zR7QOttvnvsk3DAYWsqk4Ph1jtepQeiV5rpkZHMq/RdkjUJR7gjKwj8Gb4LrHgc4mTo0YJbNUkZWgmXpSWsTQFtNRDCgbkOFBD3aMl+FW7XwwZMl5tscINIBT79JjKZEYLh/3gECRpVK4aLbQY1UTQRRPMgMkP1UpJQDAJECgYEA0hgrRBRDJb4ArOsu1xaJVXjyJBw0yCQEN6wux/HlI2W6zjrvjZtQIUlwbKCflm6cFNWznR6pWRqwHd57vJzh+YSJTySoI8G48MsE0NbhQ12pa9i10h3Ne1bYyryu4o6iYWy6Eh2SO6BJdBXLyMd+6Ml/OTWnvkdjiJ+uEolVT6MCgYEAwmXT1llcJJvSPR0uYGAg8oAUvCGGMc8eZLj7U3cNWD8EO5UKoOLzsCSfcsC5jnZwZ4lSncJxRK6ZRi2B1SkBer4dIMXlq4Gfitme+c4Cy8cSiknUhSemIw9EmcjvjaKIZw+msky0wuPHFJMoq+VZ2r2jocihGkecw6HrVhh9t0cCgYEAzljOpd8A1GD5aNzU9Iw99qUDrlPFw40cV1HV4KvE0i9oeoWIIx0YZpkqwoZAOBALXKtH7lnfGpULxUpvXaD4kYmLEyB9xCDQ9C9yW2uxc+jaLgJ7EhQTbcCuzPDlE7/j3KxdVM2Wgtm7SzjdHiZSj3DYc+gvCMQ1DktHPQ2FrOECgYB581lOOabFTH86WYkTapqgplrbnohJzO37L9RyitfzSS0Fl70gKt/G22KvoVmGlqRzP0F1uFpIROPgk4HEUEIeVw981Mj8q4eDmnvRqDw2y/7EhAZvNe1SRyy48MXe61x4kuf3KImpTS1BqgO0ul+BCsCRKIRwMQaV74jr7NdI1wKBgQCSlBVnPH5Syg50WS/uUnjkJeZosxjr1vX60lf9YUxaHuBW8s6idJcrVr93ZZN6nJC1LektZQf+OJk8JfUupY/t/I1SMGS8PA6ajqBknU0CIORYs6YTq2PeuHwsED5eIANXbFl2NHHn1M8DxU4YUMDNqbQIRUD2+NWhzJVRQVFZdw==
6b8db9a1-349d-410d-9174-7d233264ac6d	20ba8cc7-715d-4400-ad02-a88795e5f815	certificate	MIICmzCCAYMCBgGW/T1MLzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUwNTIzMTMwMTE1WhcNMzUwNTIzMTMwMjU1WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCfieIsfmouead61lqnh2xBwHQu95OB1Tzg9M/TpWuY8xVd8R9jISx1KGj42txX5R9Ucfhzuh1RXFzkRvqrAIo6yIbnfY/ffnSJ7Vb3rqVSr+Kbkw6Bcdq2t0goC+MjRvO1uZvsrH0w+DabH/3tIo/RegKMKIJM8dH6GvkLUMuuNQ9U+5UMOx+oWfsO1PChCrfmzJnGh4gQeg7RDDZLJCE/gZTL8PC/OUw+jWDtRRTIMaC1eyQtTE7pvzhxO6z6GKkFyj2aEYRWwtotz9hYPdwi3PvGvi6tL2SkBNXOxDoqQb6Y6PqvzuG7bD2p7ae4yyVllGq9wIs2fnbr9zE9LZs1AgMBAAEwDQYJKoZIhvcNAQELBQADggEBABBEu2BaT8AgVP555uNH/u1EItVZnus7LkHwZHiu0MvF0nlJHucTT5RzxUwusYFYyMzC+c9HTWNszP/GkxBZIF4zJwaEODwu4F3fu1FaGHN9DVnmctgqdoMlYF00MPlj7hj80zPvHberEbHLRD0SxL8s9i/Njh/jk18wIZTVciNgxjcP6OQvcASV22A12WBKXhvi2ivzjmTw3UQrG6ijSnLizGB39kftbCgeaNbt71rcmrAXGtYjKykXEShCH9Ru/iqtO3a1Vc3ecG4JTl2+VsQN7utuDFPxQh4kK4FYM86C9cVzGHdew3dGncT27/TFmyZemnwU3qfiKhaBEk//Ozg=
6f2ed66f-f795-4874-8027-691365b92bb1	20ba8cc7-715d-4400-ad02-a88795e5f815	priority	100
82b729dd-0cc2-4ab6-92ea-a0a182dcde83	20ba8cc7-715d-4400-ad02-a88795e5f815	keyUse	SIG
04ac9e82-f6f0-4184-a1f6-053b763f0dd8	3f9c861a-57c4-44af-88b4-b3ee2f5474b4	priority	100
8dfca3cb-eb2d-440f-8da1-2e97218a3b3c	3f9c861a-57c4-44af-88b4-b3ee2f5474b4	kid	0cbe5d9c-308b-4960-a4bb-39b3297ca22b
04ea1bf5-e222-4dc7-bfdf-39ab05fdfedf	3f9c861a-57c4-44af-88b4-b3ee2f5474b4	secret	eNxhdjK9jidw19X9t_NR8g
\.


--
-- TOC entry 4276 (class 0 OID 24608)
-- Dependencies: 233
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.composite_role (composite, child_role) FROM stdin;
899ac5a0-94ac-4833-ad72-55ef6c38dec5	da3f259d-f861-4ae3-899f-318cca57e764
899ac5a0-94ac-4833-ad72-55ef6c38dec5	7ef7ac23-8aca-4944-98cf-3a33e9927af8
899ac5a0-94ac-4833-ad72-55ef6c38dec5	26550e99-ae44-4555-9eca-24602ccb8e5d
899ac5a0-94ac-4833-ad72-55ef6c38dec5	ad0f805b-0f5e-44e4-beb2-5ce38a75c603
899ac5a0-94ac-4833-ad72-55ef6c38dec5	03fe7198-c75a-4256-a40c-f8d43feb7f21
899ac5a0-94ac-4833-ad72-55ef6c38dec5	3ffc0da3-2cc1-45cf-b2a6-9bc573b141d0
899ac5a0-94ac-4833-ad72-55ef6c38dec5	aedc2149-ef5f-4983-b302-600574a3682e
899ac5a0-94ac-4833-ad72-55ef6c38dec5	dc33c036-868c-452e-a642-68de1ecf495e
899ac5a0-94ac-4833-ad72-55ef6c38dec5	b8657608-0aac-4771-9733-2d937e72b3b4
899ac5a0-94ac-4833-ad72-55ef6c38dec5	b7031439-d454-4aa2-8007-cae90a3a612c
899ac5a0-94ac-4833-ad72-55ef6c38dec5	b902dbb8-6f86-4d14-a01b-07dc6961e7c8
899ac5a0-94ac-4833-ad72-55ef6c38dec5	91e4ec03-d06b-424a-bd9b-fe94a042b717
899ac5a0-94ac-4833-ad72-55ef6c38dec5	9aad7f23-ff8b-4da2-a85c-6c59f12e9fdd
899ac5a0-94ac-4833-ad72-55ef6c38dec5	61a8ec8d-0b99-4101-946b-a50495dbe921
899ac5a0-94ac-4833-ad72-55ef6c38dec5	5391c4c2-5c7d-45cd-a080-deaaf09267c3
899ac5a0-94ac-4833-ad72-55ef6c38dec5	09a44cc7-6c19-4738-8c55-0db964cb2a86
899ac5a0-94ac-4833-ad72-55ef6c38dec5	0b83704d-f27d-4c55-9c8d-9c32cb6db0b0
899ac5a0-94ac-4833-ad72-55ef6c38dec5	6d433096-1c14-4566-a155-adf9f759c53a
03fe7198-c75a-4256-a40c-f8d43feb7f21	09a44cc7-6c19-4738-8c55-0db964cb2a86
ad0f805b-0f5e-44e4-beb2-5ce38a75c603	6d433096-1c14-4566-a155-adf9f759c53a
ad0f805b-0f5e-44e4-beb2-5ce38a75c603	5391c4c2-5c7d-45cd-a080-deaaf09267c3
d3251d47-a2f7-4ab9-8832-42f8f7cb3052	d012ebc3-c227-423e-9ca3-25e02647ed19
d3251d47-a2f7-4ab9-8832-42f8f7cb3052	8edfa926-e35a-447f-b749-cff76e34d477
8edfa926-e35a-447f-b749-cff76e34d477	9116536d-eead-4fb7-83fa-6e33935a72b3
0afcbccc-c9a1-4e05-96c2-9bb6892ad654	ae0bf63e-45f6-4dad-948d-0d27efb93649
899ac5a0-94ac-4833-ad72-55ef6c38dec5	1c2ff5d5-4b33-496c-8b8e-7e46addc02d9
d3251d47-a2f7-4ab9-8832-42f8f7cb3052	6edb2213-95c4-4107-bf5f-43820704d291
d3251d47-a2f7-4ab9-8832-42f8f7cb3052	f4a73e48-58d7-428d-87e3-de88e94dea2a
\.


--
-- TOC entry 4277 (class 0 OID 24611)
-- Dependencies: 234
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- TOC entry 4272 (class 0 OID 24581)
-- Dependencies: 229
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2025-05-23 13:02:53.755896	1	EXECUTED	8:bda77d94bf90182a1e30c24f1c155ec7	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.16.1	\N	\N	8005373602
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2025-05-23 13:02:53.761398	2	MARK_RAN	8:1ecb330f30986693d1cba9ab579fa219	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.16.1	\N	\N	8005373602
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2025-05-23 13:02:53.779492	3	EXECUTED	8:cb7ace19bc6d959f305605d255d4c843	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.16.1	\N	\N	8005373602
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2025-05-23 13:02:53.780761	4	EXECUTED	8:80230013e961310e6872e871be424a63	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.16.1	\N	\N	8005373602
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2025-05-23 13:02:53.835229	5	EXECUTED	8:67f4c20929126adc0c8e9bf48279d244	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.16.1	\N	\N	8005373602
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2025-05-23 13:02:53.83653	6	MARK_RAN	8:7311018b0b8179ce14628ab412bb6783	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.16.1	\N	\N	8005373602
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2025-05-23 13:02:53.8678	7	EXECUTED	8:037ba1216c3640f8785ee6b8e7c8e3c1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.16.1	\N	\N	8005373602
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2025-05-23 13:02:53.868462	8	MARK_RAN	8:7fe6ffe4af4df289b3157de32c624263	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.16.1	\N	\N	8005373602
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2025-05-23 13:02:53.870095	9	EXECUTED	8:9c136bc3187083a98745c7d03bc8a303	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.16.1	\N	\N	8005373602
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2025-05-23 13:02:53.903939	10	EXECUTED	8:b5f09474dca81fb56a97cf5b6553d331	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.16.1	\N	\N	8005373602
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2025-05-23 13:02:53.92646	11	EXECUTED	8:ca924f31bd2a3b219fdcfe78c82dacf4	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.16.1	\N	\N	8005373602
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2025-05-23 13:02:53.927072	12	MARK_RAN	8:8acad7483e106416bcfa6f3b824a16cd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.16.1	\N	\N	8005373602
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2025-05-23 13:02:53.93259	13	EXECUTED	8:9b1266d17f4f87c78226f5055408fd5e	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.16.1	\N	\N	8005373602
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-05-23 13:02:53.939869	14	EXECUTED	8:d80ec4ab6dbfe573550ff72396c7e910	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.16.1	\N	\N	8005373602
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-05-23 13:02:53.940549	15	MARK_RAN	8:d86eb172171e7c20b9c849b584d147b2	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.16.1	\N	\N	8005373602
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-05-23 13:02:53.941768	16	MARK_RAN	8:5735f46f0fa60689deb0ecdc2a0dea22	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.16.1	\N	\N	8005373602
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-05-23 13:02:53.942798	17	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.16.1	\N	\N	8005373602
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2025-05-23 13:02:53.960495	18	EXECUTED	8:5c1a8fd2014ac7fc43b90a700f117b23	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.16.1	\N	\N	8005373602
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2025-05-23 13:02:53.97848	19	EXECUTED	8:1f6c2c2dfc362aff4ed75b3f0ef6b331	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.16.1	\N	\N	8005373602
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2025-05-23 13:02:53.980028	20	EXECUTED	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.16.1	\N	\N	8005373602
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2025-05-23 13:02:53.980389	21	MARK_RAN	8:9eb2ee1fa8ad1c5e426421a6f8fdfa6a	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.16.1	\N	\N	8005373602
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2025-05-23 13:02:53.981039	22	MARK_RAN	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.16.1	\N	\N	8005373602
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2025-05-23 13:02:53.986774	23	EXECUTED	8:d9fa18ffa355320395b86270680dd4fe	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.16.1	\N	\N	8005373602
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2025-05-23 13:02:53.988048	24	EXECUTED	8:90cff506fedb06141ffc1c71c4a1214c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.16.1	\N	\N	8005373602
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2025-05-23 13:02:53.988868	25	MARK_RAN	8:11a788aed4961d6d29c427c063af828c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.16.1	\N	\N	8005373602
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2025-05-23 13:02:54.00045	26	EXECUTED	8:a4218e51e1faf380518cce2af5d39b43	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.16.1	\N	\N	8005373602
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2025-05-23 13:02:54.020785	27	EXECUTED	8:d9e9a1bfaa644da9952456050f07bbdc	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.16.1	\N	\N	8005373602
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2025-05-23 13:02:54.021629	28	EXECUTED	8:d1bf991a6163c0acbfe664b615314505	update tableName=RESOURCE_SERVER_POLICY		\N	4.16.1	\N	\N	8005373602
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2025-05-23 13:02:54.04273	29	EXECUTED	8:88a743a1e87ec5e30bf603da68058a8c	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.16.1	\N	\N	8005373602
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2025-05-23 13:02:54.048005	30	EXECUTED	8:c5517863c875d325dea463d00ec26d7a	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.16.1	\N	\N	8005373602
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2025-05-23 13:02:54.05251	31	EXECUTED	8:ada8b4833b74a498f376d7136bc7d327	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.16.1	\N	\N	8005373602
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2025-05-23 13:02:54.053649	32	EXECUTED	8:b9b73c8ea7299457f99fcbb825c263ba	customChange		\N	4.16.1	\N	\N	8005373602
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-05-23 13:02:54.054915	33	EXECUTED	8:07724333e625ccfcfc5adc63d57314f3	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.16.1	\N	\N	8005373602
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-05-23 13:02:54.055226	34	MARK_RAN	8:8b6fd445958882efe55deb26fc541a7b	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.16.1	\N	\N	8005373602
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-05-23 13:02:54.063262	35	EXECUTED	8:29b29cfebfd12600897680147277a9d7	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.16.1	\N	\N	8005373602
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2025-05-23 13:02:54.064893	36	EXECUTED	8:73ad77ca8fd0410c7f9f15a471fa52bc	addColumn tableName=REALM		\N	4.16.1	\N	\N	8005373602
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-05-23 13:02:54.067007	37	EXECUTED	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.16.1	\N	\N	8005373602
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2025-05-23 13:02:54.068348	38	EXECUTED	8:27180251182e6c31846c2ddab4bc5781	addColumn tableName=FED_USER_CONSENT		\N	4.16.1	\N	\N	8005373602
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2025-05-23 13:02:54.069454	39	EXECUTED	8:d56f201bfcfa7a1413eb3e9bc02978f9	addColumn tableName=IDENTITY_PROVIDER		\N	4.16.1	\N	\N	8005373602
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-05-23 13:02:54.069865	40	MARK_RAN	8:91f5522bf6afdc2077dfab57fbd3455c	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.16.1	\N	\N	8005373602
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-05-23 13:02:54.070525	41	MARK_RAN	8:0f01b554f256c22caeb7d8aee3a1cdc8	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.16.1	\N	\N	8005373602
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2025-05-23 13:02:54.072567	42	EXECUTED	8:ab91cf9cee415867ade0e2df9651a947	customChange		\N	4.16.1	\N	\N	8005373602
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-05-23 13:02:54.111564	43	EXECUTED	8:ceac9b1889e97d602caf373eadb0d4b7	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.16.1	\N	\N	8005373602
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2025-05-23 13:02:54.112633	44	EXECUTED	8:84b986e628fe8f7fd8fd3c275c5259f2	addColumn tableName=USER_ENTITY		\N	4.16.1	\N	\N	8005373602
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-05-23 13:02:54.113597	45	EXECUTED	8:a164ae073c56ffdbc98a615493609a52	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.16.1	\N	\N	8005373602
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-05-23 13:02:54.115169	46	EXECUTED	8:70a2b4f1f4bd4dbf487114bdb1810e64	customChange		\N	4.16.1	\N	\N	8005373602
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-05-23 13:02:54.115478	47	MARK_RAN	8:7be68b71d2f5b94b8df2e824f2860fa2	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.16.1	\N	\N	8005373602
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-05-23 13:02:54.125559	48	EXECUTED	8:bab7c631093c3861d6cf6144cd944982	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.16.1	\N	\N	8005373602
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-05-23 13:02:54.126672	49	EXECUTED	8:fa809ac11877d74d76fe40869916daad	addColumn tableName=REALM		\N	4.16.1	\N	\N	8005373602
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2025-05-23 13:02:54.139115	50	EXECUTED	8:fac23540a40208f5f5e326f6ceb4d291	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.16.1	\N	\N	8005373602
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2025-05-23 13:02:54.148856	51	EXECUTED	8:2612d1b8a97e2b5588c346e817307593	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.16.1	\N	\N	8005373602
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2025-05-23 13:02:54.149656	52	EXECUTED	8:9842f155c5db2206c88bcb5d1046e941	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2025-05-23 13:02:54.150279	53	EXECUTED	8:2e12e06e45498406db72d5b3da5bbc76	update tableName=REALM		\N	4.16.1	\N	\N	8005373602
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2025-05-23 13:02:54.150816	54	EXECUTED	8:33560e7c7989250c40da3abdabdc75a4	update tableName=CLIENT		\N	4.16.1	\N	\N	8005373602
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-05-23 13:02:54.152558	55	EXECUTED	8:87a8d8542046817a9107c7eb9cbad1cd	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.16.1	\N	\N	8005373602
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-05-23 13:02:54.153806	56	EXECUTED	8:3ea08490a70215ed0088c273d776311e	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.16.1	\N	\N	8005373602
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-05-23 13:02:54.159402	57	EXECUTED	8:2d56697c8723d4592ab608ce14b6ed68	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.16.1	\N	\N	8005373602
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-05-23 13:02:54.184283	58	EXECUTED	8:3e423e249f6068ea2bbe48bf907f9d86	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.16.1	\N	\N	8005373602
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2025-05-23 13:02:54.191434	59	EXECUTED	8:15cabee5e5df0ff099510a0fc03e4103	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.16.1	\N	\N	8005373602
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2025-05-23 13:02:54.192553	60	EXECUTED	8:4b80200af916ac54d2ffbfc47918ab0e	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.16.1	\N	\N	8005373602
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-05-23 13:02:54.194569	61	EXECUTED	8:66564cd5e168045d52252c5027485bbb	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.16.1	\N	\N	8005373602
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-05-23 13:02:54.196077	62	EXECUTED	8:1c7064fafb030222be2bd16ccf690f6f	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.16.1	\N	\N	8005373602
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2025-05-23 13:02:54.196802	63	EXECUTED	8:2de18a0dce10cdda5c7e65c9b719b6e5	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.16.1	\N	\N	8005373602
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2025-05-23 13:02:54.197685	64	EXECUTED	8:03e413dd182dcbd5c57e41c34d0ef682	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.16.1	\N	\N	8005373602
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2025-05-23 13:02:54.198739	65	EXECUTED	8:d27b42bb2571c18fbe3fe4e4fb7582a7	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.16.1	\N	\N	8005373602
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2025-05-23 13:02:54.202362	66	EXECUTED	8:698baf84d9fd0027e9192717c2154fb8	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.16.1	\N	\N	8005373602
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2025-05-23 13:02:54.204032	67	EXECUTED	8:ced8822edf0f75ef26eb51582f9a821a	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.16.1	\N	\N	8005373602
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2025-05-23 13:02:54.205082	68	EXECUTED	8:f0abba004cf429e8afc43056df06487d	addColumn tableName=REALM		\N	4.16.1	\N	\N	8005373602
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2025-05-23 13:02:54.207559	69	EXECUTED	8:6662f8b0b611caa359fcf13bf63b4e24	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.16.1	\N	\N	8005373602
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2025-05-23 13:02:54.208569	70	EXECUTED	8:9e6b8009560f684250bdbdf97670d39e	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.16.1	\N	\N	8005373602
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2025-05-23 13:02:54.20948	71	EXECUTED	8:4223f561f3b8dc655846562b57bb502e	addColumn tableName=RESOURCE_SERVER		\N	4.16.1	\N	\N	8005373602
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-05-23 13:02:54.211225	72	EXECUTED	8:215a31c398b363ce383a2b301202f29e	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.16.1	\N	\N	8005373602
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-05-23 13:02:54.212468	73	EXECUTED	8:83f7a671792ca98b3cbd3a1a34862d3d	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.16.1	\N	\N	8005373602
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-05-23 13:02:54.212772	74	MARK_RAN	8:f58ad148698cf30707a6efbdf8061aa7	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.16.1	\N	\N	8005373602
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-05-23 13:02:54.21618	75	EXECUTED	8:79e4fd6c6442980e58d52ffc3ee7b19c	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.16.1	\N	\N	8005373602
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-05-23 13:02:54.218187	76	EXECUTED	8:87af6a1e6d241ca4b15801d1f86a297d	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.16.1	\N	\N	8005373602
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-05-23 13:02:54.218972	77	EXECUTED	8:b44f8d9b7b6ea455305a6d72a200ed15	addColumn tableName=CLIENT		\N	4.16.1	\N	\N	8005373602
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-05-23 13:02:54.220491	78	MARK_RAN	8:2d8ed5aaaeffd0cb004c046b4a903ac5	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.16.1	\N	\N	8005373602
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-05-23 13:02:54.225114	79	EXECUTED	8:e290c01fcbc275326c511633f6e2acde	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.16.1	\N	\N	8005373602
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-05-23 13:02:54.225437	80	MARK_RAN	8:c9db8784c33cea210872ac2d805439f8	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.16.1	\N	\N	8005373602
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-05-23 13:02:54.22696	81	EXECUTED	8:95b676ce8fc546a1fcfb4c92fae4add5	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.16.1	\N	\N	8005373602
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-05-23 13:02:54.227213	82	MARK_RAN	8:38a6b2a41f5651018b1aca93a41401e5	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.16.1	\N	\N	8005373602
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-05-23 13:02:54.228191	83	EXECUTED	8:3fb99bcad86a0229783123ac52f7609c	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.16.1	\N	\N	8005373602
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-05-23 13:02:54.228539	84	MARK_RAN	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.16.1	\N	\N	8005373602
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-05-23 13:02:54.230143	85	EXECUTED	8:ab4f863f39adafd4c862f7ec01890abc	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.16.1	\N	\N	8005373602
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2025-05-23 13:02:54.231168	86	EXECUTED	8:13c419a0eb336e91ee3a3bf8fda6e2a7	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.16.1	\N	\N	8005373602
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-05-23 13:02:54.232862	87	EXECUTED	8:e3fb1e698e0471487f51af1ed80fe3ac	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.16.1	\N	\N	8005373602
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-05-23 13:02:54.235211	88	EXECUTED	8:babadb686aab7b56562817e60bf0abd0	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.16.1	\N	\N	8005373602
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.23665	89	EXECUTED	8:72d03345fda8e2f17093d08801947773	addColumn tableName=REALM; customChange		\N	4.16.1	\N	\N	8005373602
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.237993	90	EXECUTED	8:61c9233951bd96ffecd9ba75f7d978a4	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.16.1	\N	\N	8005373602
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.23965	91	EXECUTED	8:ea82e6ad945cec250af6372767b25525	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.16.1	\N	\N	8005373602
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.241243	92	EXECUTED	8:d3f4a33f41d960ddacd7e2ef30d126b3	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.16.1	\N	\N	8005373602
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.24157	93	MARK_RAN	8:1284a27fbd049d65831cb6fc07c8a783	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.16.1	\N	\N	8005373602
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.243947	94	EXECUTED	8:9d11b619db2ae27c25853b8a37cd0dea	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.16.1	\N	\N	8005373602
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.244238	95	MARK_RAN	8:3002bb3997451bb9e8bac5c5cd8d6327	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.16.1	\N	\N	8005373602
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-05-23 13:02:54.245512	96	EXECUTED	8:dfbee0d6237a23ef4ccbb7a4e063c163	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.16.1	\N	\N	8005373602
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.248521	97	EXECUTED	8:75f3e372df18d38c62734eebb986b960	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.16.1	\N	\N	8005373602
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.248839	98	MARK_RAN	8:7fee73eddf84a6035691512c85637eef	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.252712	99	MARK_RAN	8:7a11134ab12820f999fbf3bb13c3adc8	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.255265	100	EXECUTED	8:c0f6eaac1f3be773ffe54cb5b8482b70	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.255735	101	MARK_RAN	8:18186f0008b86e0f0f49b0c4d0e842ac	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.25734	102	EXECUTED	8:09c2780bcb23b310a7019d217dc7b433	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.16.1	\N	\N	8005373602
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-05-23 13:02:54.259241	103	EXECUTED	8:276a44955eab693c970a42880197fff2	customChange		\N	4.16.1	\N	\N	8005373602
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2025-05-23 13:02:54.26166	104	EXECUTED	8:ba8ee3b694d043f2bfc1a1079d0760d7	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.16.1	\N	\N	8005373602
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2025-05-23 13:02:54.26402	105	EXECUTED	8:5e06b1d75f5d17685485e610c2851b17	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.16.1	\N	\N	8005373602
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2025-05-23 13:02:54.266049	106	EXECUTED	8:4b80546c1dc550ac552ee7b24a4ab7c0	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.16.1	\N	\N	8005373602
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2025-05-23 13:02:54.267961	107	EXECUTED	8:af510cd1bb2ab6339c45372f3e491696	customChange		\N	4.16.1	\N	\N	8005373602
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-05-23 13:02:54.270603	108	EXECUTED	8:05c99fc610845ef66ee812b7921af0ef	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.16.1	\N	\N	8005373602
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-05-23 13:02:54.271136	109	MARK_RAN	8:314e803baf2f1ec315b3464e398b8247	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.16.1	\N	\N	8005373602
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-05-23 13:02:54.273231	110	EXECUTED	8:56e4677e7e12556f70b604c573840100	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.16.1	\N	\N	8005373602
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2025-05-23 13:02:54.274931	111	EXECUTED	8:8806cb33d2a546ce770384bf98cf6eac	customChange		\N	4.16.1	\N	\N	8005373602
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-05-23 13:02:54.286959	112	EXECUTED	8:fdb2924649d30555ab3a1744faba4928	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.16.1	\N	\N	8005373602
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-05-23 13:02:54.287575	113	MARK_RAN	8:1c96cc2b10903bd07a03670098d67fd6	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.16.1	\N	\N	8005373602
\.


--
-- TOC entry 4271 (class 0 OID 24576)
-- Dependencies: 228
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- TOC entry 4355 (class 0 OID 25972)
-- Dependencies: 312
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
a23be480-b0a4-4877-a9da-504074063b45	f2f7daa1-9bb7-409b-85b5-469fa73427dd	f
a23be480-b0a4-4877-a9da-504074063b45	428404a4-d674-467d-8642-16f537671b1f	t
a23be480-b0a4-4877-a9da-504074063b45	74a4d1e9-b862-4c8e-a486-9644ae60c399	t
a23be480-b0a4-4877-a9da-504074063b45	6939ca24-2830-4a4f-99d8-6807571b3526	t
a23be480-b0a4-4877-a9da-504074063b45	a81cb08c-0422-44a6-95ea-25add888df18	f
a23be480-b0a4-4877-a9da-504074063b45	078edefc-5bd4-4565-ba6a-553b0fdda53d	f
a23be480-b0a4-4877-a9da-504074063b45	8f5eb381-11b2-4420-9940-e56c99cb64c3	t
a23be480-b0a4-4877-a9da-504074063b45	8116a500-67ea-47cb-b5cd-c6792d293b70	t
a23be480-b0a4-4877-a9da-504074063b45	f2391c60-1539-44f7-b843-29c9caef3b31	f
a23be480-b0a4-4877-a9da-504074063b45	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9	t
\.


--
-- TOC entry 4268 (class 0 OID 16485)
-- Dependencies: 225
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.document_chunks (id, document_id, chunk_index, content, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4364 (class 0 OID 26151)
-- Dependencies: 321
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.document_templates (id, name, document_type, template_content, created_at) FROM stdin;
1	Contract of Sale Template	contract	This is a template for a basic contract of sale under South African law...	2025-05-23 13:02:57.46064+00
2	Employment Contract Template	contract	Standard employment contract template compliant with Labour Relations Act...	2025-05-23 13:02:57.46064+00
3	Legal Opinion Template	opinion	Template for legal opinion documents with proper South African legal structure...	2025-05-23 13:02:57.46064+00
4	Pleading Template	pleading	Standard pleading template for South African court proceedings...	2025-05-23 13:02:57.46064+00
\.


--
-- TOC entry 4278 (class 0 OID 24616)
-- Dependencies: 235
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id) FROM stdin;
\.


--
-- TOC entry 4343 (class 0 OID 25671)
-- Dependencies: 300
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- TOC entry 4344 (class 0 OID 25676)
-- Dependencies: 301
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- TOC entry 4357 (class 0 OID 25998)
-- Dependencies: 314
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- TOC entry 4345 (class 0 OID 25685)
-- Dependencies: 302
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- TOC entry 4346 (class 0 OID 25694)
-- Dependencies: 303
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- TOC entry 4347 (class 0 OID 25697)
-- Dependencies: 304
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- TOC entry 4348 (class 0 OID 25703)
-- Dependencies: 305
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- TOC entry 4301 (class 0 OID 24993)
-- Dependencies: 258
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- TOC entry 4351 (class 0 OID 25768)
-- Dependencies: 308
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- TOC entry 4327 (class 0 OID 25395)
-- Dependencies: 284
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- TOC entry 4326 (class 0 OID 25392)
-- Dependencies: 283
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- TOC entry 4302 (class 0 OID 24998)
-- Dependencies: 259
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- TOC entry 4303 (class 0 OID 25007)
-- Dependencies: 260
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- TOC entry 4308 (class 0 OID 25111)
-- Dependencies: 265
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- TOC entry 4309 (class 0 OID 25116)
-- Dependencies: 266
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- TOC entry 4325 (class 0 OID 25389)
-- Dependencies: 282
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- TOC entry 4279 (class 0 OID 24624)
-- Dependencies: 236
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
d3251d47-a2f7-4ab9-8832-42f8f7cb3052	a23be480-b0a4-4877-a9da-504074063b45	f	${role_default-roles}	default-roles-master	a23be480-b0a4-4877-a9da-504074063b45	\N	\N
899ac5a0-94ac-4833-ad72-55ef6c38dec5	a23be480-b0a4-4877-a9da-504074063b45	f	${role_admin}	admin	a23be480-b0a4-4877-a9da-504074063b45	\N	\N
da3f259d-f861-4ae3-899f-318cca57e764	a23be480-b0a4-4877-a9da-504074063b45	f	${role_create-realm}	create-realm	a23be480-b0a4-4877-a9da-504074063b45	\N	\N
7ef7ac23-8aca-4944-98cf-3a33e9927af8	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_create-client}	create-client	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
26550e99-ae44-4555-9eca-24602ccb8e5d	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-realm}	view-realm	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
ad0f805b-0f5e-44e4-beb2-5ce38a75c603	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-users}	view-users	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
03fe7198-c75a-4256-a40c-f8d43feb7f21	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-clients}	view-clients	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
3ffc0da3-2cc1-45cf-b2a6-9bc573b141d0	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-events}	view-events	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
aedc2149-ef5f-4983-b302-600574a3682e	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-identity-providers}	view-identity-providers	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
dc33c036-868c-452e-a642-68de1ecf495e	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_view-authorization}	view-authorization	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
b8657608-0aac-4771-9733-2d937e72b3b4	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-realm}	manage-realm	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
b7031439-d454-4aa2-8007-cae90a3a612c	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-users}	manage-users	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
b902dbb8-6f86-4d14-a01b-07dc6961e7c8	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-clients}	manage-clients	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
91e4ec03-d06b-424a-bd9b-fe94a042b717	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-events}	manage-events	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
9aad7f23-ff8b-4da2-a85c-6c59f12e9fdd	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-identity-providers}	manage-identity-providers	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
61a8ec8d-0b99-4101-946b-a50495dbe921	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_manage-authorization}	manage-authorization	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
5391c4c2-5c7d-45cd-a080-deaaf09267c3	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_query-users}	query-users	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
09a44cc7-6c19-4738-8c55-0db964cb2a86	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_query-clients}	query-clients	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
0b83704d-f27d-4c55-9c8d-9c32cb6db0b0	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_query-realms}	query-realms	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
6d433096-1c14-4566-a155-adf9f759c53a	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_query-groups}	query-groups	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
d012ebc3-c227-423e-9ca3-25e02647ed19	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_view-profile}	view-profile	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
8edfa926-e35a-447f-b749-cff76e34d477	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_manage-account}	manage-account	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
9116536d-eead-4fb7-83fa-6e33935a72b3	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_manage-account-links}	manage-account-links	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
a8981d16-cd01-4c38-bc72-2adb91f2179c	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_view-applications}	view-applications	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
ae0bf63e-45f6-4dad-948d-0d27efb93649	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_view-consent}	view-consent	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
0afcbccc-c9a1-4e05-96c2-9bb6892ad654	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_manage-consent}	manage-consent	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
eddad4aa-7131-4fc8-9379-28edefce5f40	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_view-groups}	view-groups	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
1c2c03a7-792b-4e54-9daf-485785cf9a05	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	t	${role_delete-account}	delete-account	a23be480-b0a4-4877-a9da-504074063b45	e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	\N
939bd2d0-0268-4b3a-85f7-b2690399afd4	3ced503d-99ff-4fbc-8904-893f7d1a48c7	t	${role_read-token}	read-token	a23be480-b0a4-4877-a9da-504074063b45	3ced503d-99ff-4fbc-8904-893f7d1a48c7	\N
1c2ff5d5-4b33-496c-8b8e-7e46addc02d9	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	t	${role_impersonation}	impersonation	a23be480-b0a4-4877-a9da-504074063b45	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	\N
6edb2213-95c4-4107-bf5f-43820704d291	a23be480-b0a4-4877-a9da-504074063b45	f	${role_offline-access}	offline_access	a23be480-b0a4-4877-a9da-504074063b45	\N	\N
f4a73e48-58d7-428d-87e3-de88e94dea2a	a23be480-b0a4-4877-a9da-504074063b45	f	${role_uma_authorization}	uma_authorization	a23be480-b0a4-4877-a9da-504074063b45	\N	\N
\.


--
-- TOC entry 4262 (class 0 OID 16423)
-- Dependencies: 219
-- Data for Name: legal_documents; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.legal_documents (id, title, description, document_type, jurisdiction, matter_id, storage_path, file_type, created_by, created_at, updated_at, confidentiality_level) FROM stdin;
\.


--
-- TOC entry 4260 (class 0 OID 16401)
-- Dependencies: 217
-- Data for Name: legal_matters; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.legal_matters (id, title, reference_number, client_id, practice_area, responsible_attorney, created_at, updated_at, status) FROM stdin;
1	Contract Dispute - ABC Corp	MAT-2025-001	\N	Commercial Law	\N	2025-05-23 13:02:57.454791+00	2025-05-23 13:02:57.454791+00	active
2	Employment Termination Case	MAT-2025-002	\N	Labour Law	\N	2025-05-23 13:02:57.454791+00	2025-05-23 13:02:57.454791+00	active
3	Property Transfer Agreement	MAT-2025-003	\N	Property Law	\N	2025-05-23 13:02:57.454791+00	2025-05-23 13:02:57.454791+00	active
4	Compliance Review - XYZ Ltd	MAT-2025-004	\N	Corporate Law	\N	2025-05-23 13:02:57.454791+00	2025-05-23 13:02:57.454791+00	active
5	Personal Injury Claim	MAT-2025-005	\N	Civil Litigation	\N	2025-05-23 13:02:57.454791+00	2025-05-23 13:02:57.454791+00	pending
\.


--
-- TOC entry 4264 (class 0 OID 16446)
-- Dependencies: 221
-- Data for Name: legal_recordings; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.legal_recordings (id, title, description, matter_id, storage_path, duration_seconds, transcription_status, transcription_path, created_by, created_at, updated_at, recording_date) FROM stdin;
\.


--
-- TOC entry 4266 (class 0 OID 16468)
-- Dependencies: 223
-- Data for Name: legal_transcriptions; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.legal_transcriptions (id, recording_id, text_content, language, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4258 (class 0 OID 16386)
-- Dependencies: 215
-- Data for Name: legal_users; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.legal_users (id, keycloak_id, email, full_name, firm_name, role, created_at, updated_at) FROM stdin;
1	admin-keycloak-id	admin@verdict360.org	Admin User	Verdict360	admin	2025-05-23 13:02:57.452837+00	2025-05-23 13:02:57.452837+00
2	attorney1-keycloak-id	sarah@example.com	Sarah Advocate	Example Legal Firm	attorney	2025-05-23 13:02:57.452837+00	2025-05-23 13:02:57.452837+00
3	paralegal1-keycloak-id	james@example.com	James Support	Example Legal Firm	paralegal	2025-05-23 13:02:57.452837+00	2025-05-23 13:02:57.452837+00
4	client1-keycloak-id	thomas@example.com	Thomas Client	\N	client	2025-05-23 13:02:57.452837+00	2025-05-23 13:02:57.452837+00
\.


--
-- TOC entry 4307 (class 0 OID 25108)
-- Dependencies: 264
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.migration_model (id, version, update_time) FROM stdin;
itfef	21.1.1	1748005374
\.


--
-- TOC entry 4324 (class 0 OID 25380)
-- Dependencies: 281
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- TOC entry 4323 (class 0 OID 25375)
-- Dependencies: 280
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- TOC entry 4337 (class 0 OID 25594)
-- Dependencies: 294
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- TOC entry 4299 (class 0 OID 24982)
-- Dependencies: 256
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
de0c05e1-aed7-4f4d-ad37-b205a3b5dcc2	audience resolve	openid-connect	oidc-audience-resolve-mapper	b2df536b-82df-4436-b196-58ba081f1c2c	\N
1f1f9906-704a-4e15-a140-85c48fed8e60	locale	openid-connect	oidc-usermodel-attribute-mapper	ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	\N
f6594838-813f-457d-9777-92c87d97fd43	role list	saml	saml-role-list-mapper	\N	428404a4-d674-467d-8642-16f537671b1f
b1c1b4ec-a601-4dc2-b183-2c2adb22c9d4	full name	openid-connect	oidc-full-name-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
4cabf3b6-7187-4f68-8e52-37eaf56149a0	family name	openid-connect	oidc-usermodel-property-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
6b5fbf63-076c-4479-911d-d6dc45011bfb	given name	openid-connect	oidc-usermodel-property-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
88185940-7248-4e3a-b617-479190fcba87	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
9196db14-6fc8-4462-8184-7f91e6b3a3c0	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
656be4fb-af06-46a5-af9d-fec0c85e3934	username	openid-connect	oidc-usermodel-property-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
fd7e41f1-3810-4a27-b6ea-6d36701c7947	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
0f1d0184-5387-4046-bcc2-e821db25f7ab	website	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
47bdfd55-8b12-4321-8df9-74238a1c7df2	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
4e28be6b-dfc3-425f-9667-3ce37d44b931	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	74a4d1e9-b862-4c8e-a486-9644ae60c399
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	email	openid-connect	oidc-usermodel-property-mapper	\N	6939ca24-2830-4a4f-99d8-6807571b3526
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	email verified	openid-connect	oidc-usermodel-property-mapper	\N	6939ca24-2830-4a4f-99d8-6807571b3526
d14d799e-02cc-4ad2-99d0-5b14efbdb451	address	openid-connect	oidc-address-mapper	\N	a81cb08c-0422-44a6-95ea-25add888df18
bfd8446b-4ad4-4423-a734-9c2033ad3695	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	078edefc-5bd4-4565-ba6a-553b0fdda53d
d039d815-d23d-4726-9bfc-23574351afdb	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	078edefc-5bd4-4565-ba6a-553b0fdda53d
b9e6de94-7515-4333-870a-fca82e3c23e6	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	8f5eb381-11b2-4420-9940-e56c99cb64c3
feac7648-6931-4e0d-aa15-0026429134fa	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	8f5eb381-11b2-4420-9940-e56c99cb64c3
179e8bb9-afb2-4a4e-beb7-8aa94b138c74	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	8f5eb381-11b2-4420-9940-e56c99cb64c3
c04caf7d-f592-4552-aa85-1058bbe67c1f	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	8116a500-67ea-47cb-b5cd-c6792d293b70
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	upn	openid-connect	oidc-usermodel-property-mapper	\N	f2391c60-1539-44f7-b843-29c9caef3b31
37245358-3a08-496a-ab6f-7bc5cffe8d67	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	f2391c60-1539-44f7-b843-29c9caef3b31
dc75a811-7f32-4e29-944f-18c163db6950	acr loa level	openid-connect	oidc-acr-mapper	\N	f74ad1b9-2092-4f9e-ba92-4abfb1948fc9
\.


--
-- TOC entry 4300 (class 0 OID 24988)
-- Dependencies: 257
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
1f1f9906-704a-4e15-a140-85c48fed8e60	true	userinfo.token.claim
1f1f9906-704a-4e15-a140-85c48fed8e60	locale	user.attribute
1f1f9906-704a-4e15-a140-85c48fed8e60	true	id.token.claim
1f1f9906-704a-4e15-a140-85c48fed8e60	true	access.token.claim
1f1f9906-704a-4e15-a140-85c48fed8e60	locale	claim.name
1f1f9906-704a-4e15-a140-85c48fed8e60	String	jsonType.label
f6594838-813f-457d-9777-92c87d97fd43	false	single
f6594838-813f-457d-9777-92c87d97fd43	Basic	attribute.nameformat
f6594838-813f-457d-9777-92c87d97fd43	Role	attribute.name
0f1d0184-5387-4046-bcc2-e821db25f7ab	true	userinfo.token.claim
0f1d0184-5387-4046-bcc2-e821db25f7ab	website	user.attribute
0f1d0184-5387-4046-bcc2-e821db25f7ab	true	id.token.claim
0f1d0184-5387-4046-bcc2-e821db25f7ab	true	access.token.claim
0f1d0184-5387-4046-bcc2-e821db25f7ab	website	claim.name
0f1d0184-5387-4046-bcc2-e821db25f7ab	String	jsonType.label
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	true	userinfo.token.claim
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	picture	user.attribute
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	true	id.token.claim
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	true	access.token.claim
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	picture	claim.name
364f29d5-e9a6-48ce-adce-61bf6c1cf16b	String	jsonType.label
47bdfd55-8b12-4321-8df9-74238a1c7df2	true	userinfo.token.claim
47bdfd55-8b12-4321-8df9-74238a1c7df2	birthdate	user.attribute
47bdfd55-8b12-4321-8df9-74238a1c7df2	true	id.token.claim
47bdfd55-8b12-4321-8df9-74238a1c7df2	true	access.token.claim
47bdfd55-8b12-4321-8df9-74238a1c7df2	birthdate	claim.name
47bdfd55-8b12-4321-8df9-74238a1c7df2	String	jsonType.label
4cabf3b6-7187-4f68-8e52-37eaf56149a0	true	userinfo.token.claim
4cabf3b6-7187-4f68-8e52-37eaf56149a0	lastName	user.attribute
4cabf3b6-7187-4f68-8e52-37eaf56149a0	true	id.token.claim
4cabf3b6-7187-4f68-8e52-37eaf56149a0	true	access.token.claim
4cabf3b6-7187-4f68-8e52-37eaf56149a0	family_name	claim.name
4cabf3b6-7187-4f68-8e52-37eaf56149a0	String	jsonType.label
4e28be6b-dfc3-425f-9667-3ce37d44b931	true	userinfo.token.claim
4e28be6b-dfc3-425f-9667-3ce37d44b931	zoneinfo	user.attribute
4e28be6b-dfc3-425f-9667-3ce37d44b931	true	id.token.claim
4e28be6b-dfc3-425f-9667-3ce37d44b931	true	access.token.claim
4e28be6b-dfc3-425f-9667-3ce37d44b931	zoneinfo	claim.name
4e28be6b-dfc3-425f-9667-3ce37d44b931	String	jsonType.label
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	true	userinfo.token.claim
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	gender	user.attribute
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	true	id.token.claim
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	true	access.token.claim
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	gender	claim.name
5f7aba4e-bbff-4ae5-b35f-456934fdd5a5	String	jsonType.label
656be4fb-af06-46a5-af9d-fec0c85e3934	true	userinfo.token.claim
656be4fb-af06-46a5-af9d-fec0c85e3934	username	user.attribute
656be4fb-af06-46a5-af9d-fec0c85e3934	true	id.token.claim
656be4fb-af06-46a5-af9d-fec0c85e3934	true	access.token.claim
656be4fb-af06-46a5-af9d-fec0c85e3934	preferred_username	claim.name
656be4fb-af06-46a5-af9d-fec0c85e3934	String	jsonType.label
6b5fbf63-076c-4479-911d-d6dc45011bfb	true	userinfo.token.claim
6b5fbf63-076c-4479-911d-d6dc45011bfb	firstName	user.attribute
6b5fbf63-076c-4479-911d-d6dc45011bfb	true	id.token.claim
6b5fbf63-076c-4479-911d-d6dc45011bfb	true	access.token.claim
6b5fbf63-076c-4479-911d-d6dc45011bfb	given_name	claim.name
6b5fbf63-076c-4479-911d-d6dc45011bfb	String	jsonType.label
88185940-7248-4e3a-b617-479190fcba87	true	userinfo.token.claim
88185940-7248-4e3a-b617-479190fcba87	middleName	user.attribute
88185940-7248-4e3a-b617-479190fcba87	true	id.token.claim
88185940-7248-4e3a-b617-479190fcba87	true	access.token.claim
88185940-7248-4e3a-b617-479190fcba87	middle_name	claim.name
88185940-7248-4e3a-b617-479190fcba87	String	jsonType.label
9196db14-6fc8-4462-8184-7f91e6b3a3c0	true	userinfo.token.claim
9196db14-6fc8-4462-8184-7f91e6b3a3c0	nickname	user.attribute
9196db14-6fc8-4462-8184-7f91e6b3a3c0	true	id.token.claim
9196db14-6fc8-4462-8184-7f91e6b3a3c0	true	access.token.claim
9196db14-6fc8-4462-8184-7f91e6b3a3c0	nickname	claim.name
9196db14-6fc8-4462-8184-7f91e6b3a3c0	String	jsonType.label
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	true	userinfo.token.claim
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	updatedAt	user.attribute
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	true	id.token.claim
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	true	access.token.claim
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	updated_at	claim.name
b18e9d1b-ea8f-4beb-869b-af5db0d3a77b	long	jsonType.label
b1c1b4ec-a601-4dc2-b183-2c2adb22c9d4	true	userinfo.token.claim
b1c1b4ec-a601-4dc2-b183-2c2adb22c9d4	true	id.token.claim
b1c1b4ec-a601-4dc2-b183-2c2adb22c9d4	true	access.token.claim
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	true	userinfo.token.claim
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	locale	user.attribute
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	true	id.token.claim
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	true	access.token.claim
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	locale	claim.name
b2a3a089-4b0f-4e78-b349-c6596b9e9a98	String	jsonType.label
fd7e41f1-3810-4a27-b6ea-6d36701c7947	true	userinfo.token.claim
fd7e41f1-3810-4a27-b6ea-6d36701c7947	profile	user.attribute
fd7e41f1-3810-4a27-b6ea-6d36701c7947	true	id.token.claim
fd7e41f1-3810-4a27-b6ea-6d36701c7947	true	access.token.claim
fd7e41f1-3810-4a27-b6ea-6d36701c7947	profile	claim.name
fd7e41f1-3810-4a27-b6ea-6d36701c7947	String	jsonType.label
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	true	userinfo.token.claim
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	emailVerified	user.attribute
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	true	id.token.claim
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	true	access.token.claim
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	email_verified	claim.name
1a228cf0-b509-4e18-addf-bb3dafdcb2e4	boolean	jsonType.label
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	true	userinfo.token.claim
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	email	user.attribute
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	true	id.token.claim
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	true	access.token.claim
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	email	claim.name
c866d4e8-da22-4d17-8dd8-e7294bfaaf15	String	jsonType.label
d14d799e-02cc-4ad2-99d0-5b14efbdb451	formatted	user.attribute.formatted
d14d799e-02cc-4ad2-99d0-5b14efbdb451	country	user.attribute.country
d14d799e-02cc-4ad2-99d0-5b14efbdb451	postal_code	user.attribute.postal_code
d14d799e-02cc-4ad2-99d0-5b14efbdb451	true	userinfo.token.claim
d14d799e-02cc-4ad2-99d0-5b14efbdb451	street	user.attribute.street
d14d799e-02cc-4ad2-99d0-5b14efbdb451	true	id.token.claim
d14d799e-02cc-4ad2-99d0-5b14efbdb451	region	user.attribute.region
d14d799e-02cc-4ad2-99d0-5b14efbdb451	true	access.token.claim
d14d799e-02cc-4ad2-99d0-5b14efbdb451	locality	user.attribute.locality
bfd8446b-4ad4-4423-a734-9c2033ad3695	true	userinfo.token.claim
bfd8446b-4ad4-4423-a734-9c2033ad3695	phoneNumber	user.attribute
bfd8446b-4ad4-4423-a734-9c2033ad3695	true	id.token.claim
bfd8446b-4ad4-4423-a734-9c2033ad3695	true	access.token.claim
bfd8446b-4ad4-4423-a734-9c2033ad3695	phone_number	claim.name
bfd8446b-4ad4-4423-a734-9c2033ad3695	String	jsonType.label
d039d815-d23d-4726-9bfc-23574351afdb	true	userinfo.token.claim
d039d815-d23d-4726-9bfc-23574351afdb	phoneNumberVerified	user.attribute
d039d815-d23d-4726-9bfc-23574351afdb	true	id.token.claim
d039d815-d23d-4726-9bfc-23574351afdb	true	access.token.claim
d039d815-d23d-4726-9bfc-23574351afdb	phone_number_verified	claim.name
d039d815-d23d-4726-9bfc-23574351afdb	boolean	jsonType.label
b9e6de94-7515-4333-870a-fca82e3c23e6	true	multivalued
b9e6de94-7515-4333-870a-fca82e3c23e6	foo	user.attribute
b9e6de94-7515-4333-870a-fca82e3c23e6	true	access.token.claim
b9e6de94-7515-4333-870a-fca82e3c23e6	realm_access.roles	claim.name
b9e6de94-7515-4333-870a-fca82e3c23e6	String	jsonType.label
feac7648-6931-4e0d-aa15-0026429134fa	true	multivalued
feac7648-6931-4e0d-aa15-0026429134fa	foo	user.attribute
feac7648-6931-4e0d-aa15-0026429134fa	true	access.token.claim
feac7648-6931-4e0d-aa15-0026429134fa	resource_access.${client_id}.roles	claim.name
feac7648-6931-4e0d-aa15-0026429134fa	String	jsonType.label
37245358-3a08-496a-ab6f-7bc5cffe8d67	true	multivalued
37245358-3a08-496a-ab6f-7bc5cffe8d67	foo	user.attribute
37245358-3a08-496a-ab6f-7bc5cffe8d67	true	id.token.claim
37245358-3a08-496a-ab6f-7bc5cffe8d67	true	access.token.claim
37245358-3a08-496a-ab6f-7bc5cffe8d67	groups	claim.name
37245358-3a08-496a-ab6f-7bc5cffe8d67	String	jsonType.label
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	true	userinfo.token.claim
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	username	user.attribute
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	true	id.token.claim
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	true	access.token.claim
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	upn	claim.name
ac11107f-16ca-4d59-a2bb-55b7ad4d95fd	String	jsonType.label
dc75a811-7f32-4e29-944f-18c163db6950	true	id.token.claim
dc75a811-7f32-4e29-944f-18c163db6950	true	access.token.claim
\.


--
-- TOC entry 4280 (class 0 OID 24630)
-- Dependencies: 237
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
a23be480-b0a4-4877-a9da-504074063b45	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	662ea99a-a93e-44cd-9d0f-3a11d68cbee8	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	da887d0d-b7a6-44a8-a808-95cf095ecba5	6d2d6791-437c-489c-a7f5-a7b59b1e3284	d852cd57-804e-4d02-84a0-ee588b21d358	95228ca5-7b92-4900-a1d7-6640c9af224d	b1e8fefb-85b5-4657-a7b5-551ec8a3e04d	2592000	f	900	t	f	5d7ee496-1013-4cbb-ad0b-9977dfcb1c5a	0	f	0	0	d3251d47-a2f7-4ab9-8832-42f8f7cb3052
\.


--
-- TOC entry 4281 (class 0 OID 24647)
-- Dependencies: 238
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	a23be480-b0a4-4877-a9da-504074063b45	
_browser_header.xContentTypeOptions	a23be480-b0a4-4877-a9da-504074063b45	nosniff
_browser_header.xRobotsTag	a23be480-b0a4-4877-a9da-504074063b45	none
_browser_header.xFrameOptions	a23be480-b0a4-4877-a9da-504074063b45	SAMEORIGIN
_browser_header.contentSecurityPolicy	a23be480-b0a4-4877-a9da-504074063b45	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	a23be480-b0a4-4877-a9da-504074063b45	1; mode=block
_browser_header.strictTransportSecurity	a23be480-b0a4-4877-a9da-504074063b45	max-age=31536000; includeSubDomains
bruteForceProtected	a23be480-b0a4-4877-a9da-504074063b45	false
permanentLockout	a23be480-b0a4-4877-a9da-504074063b45	false
maxFailureWaitSeconds	a23be480-b0a4-4877-a9da-504074063b45	900
minimumQuickLoginWaitSeconds	a23be480-b0a4-4877-a9da-504074063b45	60
waitIncrementSeconds	a23be480-b0a4-4877-a9da-504074063b45	60
quickLoginCheckMilliSeconds	a23be480-b0a4-4877-a9da-504074063b45	1000
maxDeltaTimeSeconds	a23be480-b0a4-4877-a9da-504074063b45	43200
failureFactor	a23be480-b0a4-4877-a9da-504074063b45	30
realmReusableOtpCode	a23be480-b0a4-4877-a9da-504074063b45	false
displayName	a23be480-b0a4-4877-a9da-504074063b45	Keycloak
displayNameHtml	a23be480-b0a4-4877-a9da-504074063b45	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	a23be480-b0a4-4877-a9da-504074063b45	RS256
offlineSessionMaxLifespanEnabled	a23be480-b0a4-4877-a9da-504074063b45	false
offlineSessionMaxLifespan	a23be480-b0a4-4877-a9da-504074063b45	5184000
\.


--
-- TOC entry 4329 (class 0 OID 25404)
-- Dependencies: 286
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- TOC entry 4306 (class 0 OID 25100)
-- Dependencies: 263
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- TOC entry 4282 (class 0 OID 24655)
-- Dependencies: 239
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
a23be480-b0a4-4877-a9da-504074063b45	jboss-logging
\.


--
-- TOC entry 4362 (class 0 OID 26106)
-- Dependencies: 319
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- TOC entry 4283 (class 0 OID 24658)
-- Dependencies: 240
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	a23be480-b0a4-4877-a9da-504074063b45
\.


--
-- TOC entry 4284 (class 0 OID 24665)
-- Dependencies: 241
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- TOC entry 4304 (class 0 OID 25016)
-- Dependencies: 261
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- TOC entry 4285 (class 0 OID 24675)
-- Dependencies: 242
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.redirect_uris (client_id, value) FROM stdin;
e1df67f8-1b0e-42c8-9d9a-b6e6539010d2	/realms/master/account/*
b2df536b-82df-4436-b196-58ba081f1c2c	/realms/master/account/*
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	/admin/master/console/*
\.


--
-- TOC entry 4322 (class 0 OID 25339)
-- Dependencies: 279
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- TOC entry 4321 (class 0 OID 25332)
-- Dependencies: 278
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
e7c10710-3ace-4104-b022-23a2c55249d3	VERIFY_EMAIL	Verify Email	a23be480-b0a4-4877-a9da-504074063b45	t	f	VERIFY_EMAIL	50
320bac04-583e-4bc5-bc5a-0da742cb87a8	UPDATE_PROFILE	Update Profile	a23be480-b0a4-4877-a9da-504074063b45	t	f	UPDATE_PROFILE	40
45b0ad55-d535-4afa-bdc6-ce5f1f71b24d	CONFIGURE_TOTP	Configure OTP	a23be480-b0a4-4877-a9da-504074063b45	t	f	CONFIGURE_TOTP	10
5c429728-aa50-47e8-a6b3-d7e50ad78e06	UPDATE_PASSWORD	Update Password	a23be480-b0a4-4877-a9da-504074063b45	t	f	UPDATE_PASSWORD	30
ba55d83d-07a8-4366-9d5e-3fb65c449f72	TERMS_AND_CONDITIONS	Terms and Conditions	a23be480-b0a4-4877-a9da-504074063b45	f	f	TERMS_AND_CONDITIONS	20
117cb41a-c47e-4e2b-b3e3-105123afcad3	delete_account	Delete Account	a23be480-b0a4-4877-a9da-504074063b45	f	f	delete_account	60
6ef01468-85ce-4bb9-8cd6-108e7dc3aa82	update_user_locale	Update User Locale	a23be480-b0a4-4877-a9da-504074063b45	t	f	update_user_locale	1000
71d46d67-6d58-4a89-9f3f-4403d89a38e8	webauthn-register	Webauthn Register	a23be480-b0a4-4877-a9da-504074063b45	t	f	webauthn-register	70
3213befe-11ba-422f-bae0-9a990a9dae19	webauthn-register-passwordless	Webauthn Register Passwordless	a23be480-b0a4-4877-a9da-504074063b45	t	f	webauthn-register-passwordless	80
\.


--
-- TOC entry 4359 (class 0 OID 26037)
-- Dependencies: 316
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- TOC entry 4339 (class 0 OID 25621)
-- Dependencies: 296
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- TOC entry 4338 (class 0 OID 25606)
-- Dependencies: 295
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- TOC entry 4333 (class 0 OID 25544)
-- Dependencies: 290
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- TOC entry 4358 (class 0 OID 26013)
-- Dependencies: 315
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- TOC entry 4336 (class 0 OID 25580)
-- Dependencies: 293
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- TOC entry 4334 (class 0 OID 25552)
-- Dependencies: 291
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- TOC entry 4335 (class 0 OID 25566)
-- Dependencies: 292
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- TOC entry 4360 (class 0 OID 26055)
-- Dependencies: 317
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- TOC entry 4361 (class 0 OID 26065)
-- Dependencies: 318
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- TOC entry 4286 (class 0 OID 24678)
-- Dependencies: 243
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
b2df536b-82df-4436-b196-58ba081f1c2c	eddad4aa-7131-4fc8-9379-28edefce5f40
b2df536b-82df-4436-b196-58ba081f1c2c	8edfa926-e35a-447f-b749-cff76e34d477
\.


--
-- TOC entry 4340 (class 0 OID 25636)
-- Dependencies: 297
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- TOC entry 4365 (class 0 OID 26160)
-- Dependencies: 322
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.system_config (key, value, description, created_at, updated_at) FROM stdin;
default_jurisdiction	South Africa	Default jurisdiction for legal documents	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
firm_name	Example Legal Firm	Default firm name for development	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
currency	ZAR	Default currency (South African Rand)	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
date_format	DD/MM/YYYY	Default date format for South African locale	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
max_upload_size	20971520	Maximum file upload size in bytes (20MB)	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
retention_period_years	7	Default document retention period in years	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
backup_frequency_hours	24	Backup frequency in hours	2025-05-23 13:02:57.464024+00	2025-05-23 13:02:57.464024+00
\.


--
-- TOC entry 4288 (class 0 OID 24684)
-- Dependencies: 245
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
\.


--
-- TOC entry 4310 (class 0 OID 25121)
-- Dependencies: 267
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- TOC entry 4356 (class 0 OID 25988)
-- Dependencies: 313
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- TOC entry 4289 (class 0 OID 24689)
-- Dependencies: 246
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
\.


--
-- TOC entry 4290 (class 0 OID 24697)
-- Dependencies: 247
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- TOC entry 4317 (class 0 OID 25233)
-- Dependencies: 274
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- TOC entry 4318 (class 0 OID 25238)
-- Dependencies: 275
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- TOC entry 4291 (class 0 OID 24702)
-- Dependencies: 248
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- TOC entry 4328 (class 0 OID 25401)
-- Dependencies: 285
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- TOC entry 4292 (class 0 OID 24707)
-- Dependencies: 249
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- TOC entry 4293 (class 0 OID 24710)
-- Dependencies: 250
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
\.


--
-- TOC entry 4294 (class 0 OID 24713)
-- Dependencies: 251
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- TOC entry 4305 (class 0 OID 25019)
-- Dependencies: 262
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- TOC entry 4287 (class 0 OID 24681)
-- Dependencies: 244
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- TOC entry 4295 (class 0 OID 24724)
-- Dependencies: 252
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: Verdict360
--

COPY public.web_origins (client_id, value) FROM stdin;
ce33fe2d-61fe-4544-aad9-4f9f8c3b1d9d	+
\.


--
-- TOC entry 4380 (class 0 OID 0)
-- Dependencies: 226
-- Name: case_law_references_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.case_law_references_id_seq', 5, true);


--
-- TOC entry 4381 (class 0 OID 0)
-- Dependencies: 224
-- Name: document_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.document_chunks_id_seq', 1, false);


--
-- TOC entry 4382 (class 0 OID 0)
-- Dependencies: 320
-- Name: document_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.document_templates_id_seq', 4, true);


--
-- TOC entry 4383 (class 0 OID 0)
-- Dependencies: 218
-- Name: legal_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.legal_documents_id_seq', 1, false);


--
-- TOC entry 4384 (class 0 OID 0)
-- Dependencies: 216
-- Name: legal_matters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.legal_matters_id_seq', 5, true);


--
-- TOC entry 4385 (class 0 OID 0)
-- Dependencies: 220
-- Name: legal_recordings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.legal_recordings_id_seq', 1, false);


--
-- TOC entry 4386 (class 0 OID 0)
-- Dependencies: 222
-- Name: legal_transcriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.legal_transcriptions_id_seq', 1, false);


--
-- TOC entry 4387 (class 0 OID 0)
-- Dependencies: 214
-- Name: legal_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Verdict360
--

SELECT pg_catalog.setval('public.legal_users_id_seq', 4, true);


--
-- TOC entry 3785 (class 2606 OID 25780)
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- TOC entry 3758 (class 2606 OID 26089)
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- TOC entry 4001 (class 2606 OID 25919)
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- TOC entry 4003 (class 2606 OID 26118)
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- TOC entry 3730 (class 2606 OID 16511)
-- Name: case_law_references case_law_references_citation_key; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.case_law_references
    ADD CONSTRAINT case_law_references_citation_key UNIQUE (citation);


--
-- TOC entry 3732 (class 2606 OID 16509)
-- Name: case_law_references case_law_references_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.case_law_references
    ADD CONSTRAINT case_law_references_pkey PRIMARY KEY (id);


--
-- TOC entry 3998 (class 2606 OID 25794)
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- TOC entry 3915 (class 2606 OID 25442)
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- TOC entry 3963 (class 2606 OID 25717)
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- TOC entry 3884 (class 2606 OID 25351)
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- TOC entry 3989 (class 2606 OID 25737)
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- TOC entry 3992 (class 2606 OID 25735)
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- TOC entry 3981 (class 2606 OID 25733)
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- TOC entry 3965 (class 2606 OID 25719)
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- TOC entry 3968 (class 2606 OID 25721)
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- TOC entry 3973 (class 2606 OID 25727)
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- TOC entry 3977 (class 2606 OID 25729)
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- TOC entry 3985 (class 2606 OID 25731)
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- TOC entry 3996 (class 2606 OID 25774)
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- TOC entry 3917 (class 2606 OID 25878)
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- TOC entry 3843 (class 2606 OID 25895)
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- TOC entry 3772 (class 2606 OID 25897)
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- TOC entry 3838 (class 2606 OID 25899)
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- TOC entry 3831 (class 2606 OID 25028)
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- TOC entry 3815 (class 2606 OID 24962)
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- TOC entry 3755 (class 2606 OID 24736)
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- TOC entry 3827 (class 2606 OID 25030)
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- TOC entry 3764 (class 2606 OID 24738)
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- TOC entry 3746 (class 2606 OID 24740)
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- TOC entry 3810 (class 2606 OID 24742)
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- TOC entry 3801 (class 2606 OID 24744)
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- TOC entry 3817 (class 2606 OID 24964)
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- TOC entry 3738 (class 2606 OID 24748)
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- TOC entry 3743 (class 2606 OID 24750)
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- TOC entry 3782 (class 2606 OID 24752)
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- TOC entry 3819 (class 2606 OID 24966)
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- TOC entry 3769 (class 2606 OID 24754)
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- TOC entry 3775 (class 2606 OID 24756)
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- TOC entry 3760 (class 2606 OID 24758)
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- TOC entry 3861 (class 2606 OID 25882)
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- TOC entry 3874 (class 2606 OID 25259)
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- TOC entry 3870 (class 2606 OID 25257)
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- TOC entry 3867 (class 2606 OID 25255)
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- TOC entry 3864 (class 2606 OID 25253)
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- TOC entry 3882 (class 2606 OID 25263)
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- TOC entry 3807 (class 2606 OID 24760)
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- TOC entry 3748 (class 2606 OID 25876)
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- TOC entry 3859 (class 2606 OID 25146)
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- TOC entry 3836 (class 2606 OID 25032)
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- TOC entry 3949 (class 2606 OID 25600)
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- TOC entry 3777 (class 2606 OID 24762)
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- TOC entry 3752 (class 2606 OID 24764)
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- TOC entry 3799 (class 2606 OID 24766)
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- TOC entry 4016 (class 2606 OID 26017)
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- TOC entry 3934 (class 2606 OID 25558)
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- TOC entry 3944 (class 2606 OID 25586)
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- TOC entry 3960 (class 2606 OID 25655)
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- TOC entry 3954 (class 2606 OID 25625)
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- TOC entry 3939 (class 2606 OID 25572)
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- TOC entry 3951 (class 2606 OID 25610)
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- TOC entry 3957 (class 2606 OID 25640)
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- TOC entry 3791 (class 2606 OID 24768)
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- TOC entry 3880 (class 2606 OID 25267)
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- TOC entry 3876 (class 2606 OID 25265)
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 26002)
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- TOC entry 4011 (class 2606 OID 25992)
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- TOC entry 3854 (class 2606 OID 25140)
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- TOC entry 3901 (class 2606 OID 25409)
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- TOC entry 3908 (class 2606 OID 25416)
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- TOC entry 3905 (class 2606 OID 25430)
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- TOC entry 3849 (class 2606 OID 25136)
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- TOC entry 3852 (class 2606 OID 25316)
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- TOC entry 3846 (class 2606 OID 25134)
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- TOC entry 3897 (class 2606 OID 26095)
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- TOC entry 3891 (class 2606 OID 25386)
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- TOC entry 3821 (class 2606 OID 25026)
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- TOC entry 3825 (class 2606 OID 25309)
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- TOC entry 3779 (class 2606 OID 25901)
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- TOC entry 3889 (class 2606 OID 25349)
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- TOC entry 3886 (class 2606 OID 25347)
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- TOC entry 3804 (class 2606 OID 25261)
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- TOC entry 4022 (class 2606 OID 26064)
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- TOC entry 4024 (class 2606 OID 26071)
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- TOC entry 3787 (class 2606 OID 25345)
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- TOC entry 3912 (class 2606 OID 25423)
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- TOC entry 3841 (class 2606 OID 25036)
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- TOC entry 3812 (class 2606 OID 25903)
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- TOC entry 3736 (class 2606 OID 24580)
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- TOC entry 3727 (class 2606 OID 16493)
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- TOC entry 4029 (class 2606 OID 26159)
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3721 (class 2606 OID 16434)
-- Name: legal_documents legal_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_documents
    ADD CONSTRAINT legal_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 3717 (class 2606 OID 16411)
-- Name: legal_matters legal_matters_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_matters
    ADD CONSTRAINT legal_matters_pkey PRIMARY KEY (id);


--
-- TOC entry 3723 (class 2606 OID 16456)
-- Name: legal_recordings legal_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_recordings
    ADD CONSTRAINT legal_recordings_pkey PRIMARY KEY (id);


--
-- TOC entry 3725 (class 2606 OID 16478)
-- Name: legal_transcriptions legal_transcriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_transcriptions
    ADD CONSTRAINT legal_transcriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 3710 (class 2606 OID 16399)
-- Name: legal_users legal_users_email_key; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_users
    ADD CONSTRAINT legal_users_email_key UNIQUE (email);


--
-- TOC entry 3712 (class 2606 OID 16397)
-- Name: legal_users legal_users_keycloak_id_key; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_users
    ADD CONSTRAINT legal_users_keycloak_id_key UNIQUE (keycloak_id);


--
-- TOC entry 3714 (class 2606 OID 16395)
-- Name: legal_users legal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_users
    ADD CONSTRAINT legal_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3926 (class 2606 OID 25526)
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- TOC entry 3921 (class 2606 OID 25485)
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- TOC entry 3932 (class 2606 OID 25856)
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- TOC entry 3930 (class 2606 OID 25514)
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- TOC entry 4009 (class 2606 OID 25977)
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- TOC entry 4027 (class 2606 OID 26112)
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- TOC entry 4020 (class 2606 OID 26044)
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- TOC entry 3903 (class 2606 OID 25786)
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- TOC entry 4031 (class 2606 OID 26168)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- TOC entry 3834 (class 2606 OID 25083)
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- TOC entry 3741 (class 2606 OID 24772)
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- TOC entry 3923 (class 2606 OID 25930)
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- TOC entry 3795 (class 2606 OID 24776)
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- TOC entry 3937 (class 2606 OID 26103)
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- TOC entry 4018 (class 2606 OID 26099)
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- TOC entry 3947 (class 2606 OID 25847)
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- TOC entry 3942 (class 2606 OID 25851)
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- TOC entry 3857 (class 2606 OID 26091)
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- TOC entry 3767 (class 2606 OID 24784)
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- TOC entry 3797 (class 2606 OID 25776)
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- TOC entry 3862 (class 1259 OID 26128)
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- TOC entry 3961 (class 1259 OID 25800)
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- TOC entry 3865 (class 1259 OID 25804)
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- TOC entry 3871 (class 1259 OID 25802)
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- TOC entry 3872 (class 1259 OID 25801)
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- TOC entry 3868 (class 1259 OID 25803)
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- TOC entry 3733 (class 1259 OID 16521)
-- Name: idx_case_law_references_citation; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_case_law_references_citation ON public.case_law_references USING btree (citation);


--
-- TOC entry 3734 (class 1259 OID 16522)
-- Name: idx_case_law_references_court_year; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_case_law_references_court_year ON public.case_law_references USING btree (court, year);


--
-- TOC entry 4004 (class 1259 OID 26119)
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- TOC entry 3739 (class 1259 OID 26104)
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- TOC entry 3999 (class 1259 OID 25844)
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- TOC entry 3744 (class 1259 OID 25808)
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- TOC entry 3924 (class 1259 OID 26007)
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- TOC entry 4005 (class 1259 OID 26116)
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- TOC entry 3822 (class 1259 OID 26004)
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- TOC entry 3927 (class 1259 OID 26005)
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- TOC entry 3990 (class 1259 OID 25810)
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- TOC entry 3993 (class 1259 OID 26078)
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- TOC entry 3994 (class 1259 OID 25809)
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- TOC entry 3749 (class 1259 OID 25811)
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- TOC entry 3750 (class 1259 OID 25812)
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- TOC entry 4006 (class 1259 OID 26010)
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- TOC entry 4007 (class 1259 OID 26011)
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- TOC entry 3728 (class 1259 OID 16517)
-- Name: idx_document_chunks_metadata; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_document_chunks_metadata ON public.document_chunks USING gin (metadata jsonb_path_ops);


--
-- TOC entry 3756 (class 1259 OID 26105)
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- TOC entry 3828 (class 1259 OID 25543)
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- TOC entry 3829 (class 1259 OID 25542)
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- TOC entry 3966 (class 1259 OID 25904)
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- TOC entry 3969 (class 1259 OID 25924)
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- TOC entry 3970 (class 1259 OID 26087)
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- TOC entry 3971 (class 1259 OID 25906)
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- TOC entry 3974 (class 1259 OID 25907)
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- TOC entry 3975 (class 1259 OID 25908)
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- TOC entry 3978 (class 1259 OID 25909)
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- TOC entry 3979 (class 1259 OID 25910)
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- TOC entry 3982 (class 1259 OID 25911)
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- TOC entry 3983 (class 1259 OID 25912)
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- TOC entry 3986 (class 1259 OID 25913)
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- TOC entry 3987 (class 1259 OID 25914)
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- TOC entry 3909 (class 1259 OID 26129)
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- TOC entry 3910 (class 1259 OID 25815)
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- TOC entry 3906 (class 1259 OID 25816)
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- TOC entry 3850 (class 1259 OID 25818)
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- TOC entry 3832 (class 1259 OID 25817)
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- TOC entry 3761 (class 1259 OID 25819)
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- TOC entry 3762 (class 1259 OID 25820)
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- TOC entry 3718 (class 1259 OID 16519)
-- Name: idx_legal_documents_jurisdiction; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_legal_documents_jurisdiction ON public.legal_documents USING btree (jurisdiction);


--
-- TOC entry 3719 (class 1259 OID 16518)
-- Name: idx_legal_documents_type; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_legal_documents_type ON public.legal_documents USING btree (document_type);


--
-- TOC entry 3715 (class 1259 OID 16520)
-- Name: idx_legal_matters_practice_area; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_legal_matters_practice_area ON public.legal_matters USING btree (practice_area);


--
-- TOC entry 3898 (class 1259 OID 26122)
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- TOC entry 3892 (class 1259 OID 26123)
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- TOC entry 3893 (class 1259 OID 26124)
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- TOC entry 3894 (class 1259 OID 26082)
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- TOC entry 3895 (class 1259 OID 26113)
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- TOC entry 3823 (class 1259 OID 25821)
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- TOC entry 3770 (class 1259 OID 25824)
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- TOC entry 3919 (class 1259 OID 26003)
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- TOC entry 3918 (class 1259 OID 25825)
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- TOC entry 3773 (class 1259 OID 25828)
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- TOC entry 3844 (class 1259 OID 25827)
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- TOC entry 3765 (class 1259 OID 25823)
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- TOC entry 3839 (class 1259 OID 25829)
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- TOC entry 3780 (class 1259 OID 25830)
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- TOC entry 3887 (class 1259 OID 25831)
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- TOC entry 3955 (class 1259 OID 25832)
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- TOC entry 3952 (class 1259 OID 25833)
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- TOC entry 3945 (class 1259 OID 25852)
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- TOC entry 3935 (class 1259 OID 25853)
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- TOC entry 3940 (class 1259 OID 25854)
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- TOC entry 4025 (class 1259 OID 26077)
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- TOC entry 3928 (class 1259 OID 26006)
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- TOC entry 3783 (class 1259 OID 25837)
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- TOC entry 3958 (class 1259 OID 25838)
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- TOC entry 3847 (class 1259 OID 26085)
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- TOC entry 3899 (class 1259 OID 25532)
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- TOC entry 4012 (class 1259 OID 26012)
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- TOC entry 3788 (class 1259 OID 25539)
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- TOC entry 3789 (class 1259 OID 26126)
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- TOC entry 3855 (class 1259 OID 25536)
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- TOC entry 3753 (class 1259 OID 25540)
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- TOC entry 3792 (class 1259 OID 25533)
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- TOC entry 3913 (class 1259 OID 25535)
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- TOC entry 3805 (class 1259 OID 25541)
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- TOC entry 3808 (class 1259 OID 25534)
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- TOC entry 3793 (class 1259 OID 26127)
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- TOC entry 3877 (class 1259 OID 25840)
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- TOC entry 3878 (class 1259 OID 25841)
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- TOC entry 3802 (class 1259 OID 25842)
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- TOC entry 3813 (class 1259 OID 25843)
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: Verdict360
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- TOC entry 4082 (class 2606 OID 25268)
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- TOC entry 4040 (class 2606 OID 16512)
-- Name: case_law_references case_law_references_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.case_law_references
    ADD CONSTRAINT case_law_references_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.legal_documents(id);


--
-- TOC entry 4039 (class 2606 OID 16494)
-- Name: document_chunks document_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.legal_documents(id) ON DELETE CASCADE;


--
-- TOC entry 4066 (class 2606 OID 25037)
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4059 (class 2606 OID 24967)
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4065 (class 2606 OID 25047)
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4061 (class 2606 OID 25194)
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4060 (class 2606 OID 24972)
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- TOC entry 4069 (class 2606 OID 25077)
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- TOC entry 4042 (class 2606 OID 24787)
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- TOC entry 4051 (class 2606 OID 24792)
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4055 (class 2606 OID 24797)
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4074 (class 2606 OID 25172)
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- TOC entry 4049 (class 2606 OID 24807)
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4112 (class 2606 OID 26045)
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- TOC entry 4053 (class 2606 OID 24812)
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4056 (class 2606 OID 24822)
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4046 (class 2606 OID 24827)
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- TOC entry 4050 (class 2606 OID 24832)
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4047 (class 2606 OID 24847)
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4043 (class 2606 OID 24852)
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- TOC entry 4077 (class 2606 OID 25288)
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- TOC entry 4078 (class 2606 OID 25283)
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4076 (class 2606 OID 25278)
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4075 (class 2606 OID 25273)
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4041 (class 2606 OID 24857)
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- TOC entry 4057 (class 2606 OID 24862)
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4089 (class 2606 OID 25951)
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- TOC entry 4090 (class 2606 OID 25941)
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- TOC entry 4083 (class 2606 OID 25357)
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- TOC entry 4062 (class 2606 OID 25936)
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- TOC entry 4105 (class 2606 OID 25795)
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4103 (class 2606 OID 25743)
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- TOC entry 4104 (class 2606 OID 25738)
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4088 (class 2606 OID 25443)
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4081 (class 2606 OID 25303)
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- TOC entry 4079 (class 2606 OID 25298)
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- TOC entry 4080 (class 2606 OID 25293)
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4101 (class 2606 OID 25661)
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4099 (class 2606 OID 25646)
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4108 (class 2606 OID 26018)
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- TOC entry 4091 (class 2606 OID 25862)
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- TOC entry 4109 (class 2606 OID 26023)
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- TOC entry 4110 (class 2606 OID 26028)
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- TOC entry 4102 (class 2606 OID 25656)
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4100 (class 2606 OID 25641)
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- TOC entry 4111 (class 2606 OID 26050)
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4093 (class 2606 OID 25857)
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- TOC entry 4095 (class 2606 OID 25611)
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- TOC entry 4097 (class 2606 OID 25626)
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- TOC entry 4098 (class 2606 OID 25631)
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4096 (class 2606 OID 25616)
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- TOC entry 4092 (class 2606 OID 25867)
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- TOC entry 4044 (class 2606 OID 24877)
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- TOC entry 4107 (class 2606 OID 25993)
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- TOC entry 4073 (class 2606 OID 25157)
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4086 (class 2606 OID 25417)
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- TOC entry 4085 (class 2606 OID 25431)
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- TOC entry 4070 (class 2606 OID 25103)
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4048 (class 2606 OID 24887)
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4071 (class 2606 OID 25147)
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4072 (class 2606 OID 25317)
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- TOC entry 4058 (class 2606 OID 24897)
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4052 (class 2606 OID 24907)
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4063 (class 2606 OID 25042)
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- TOC entry 4045 (class 2606 OID 24922)
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4064 (class 2606 OID 25310)
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- TOC entry 4106 (class 2606 OID 25978)
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4084 (class 2606 OID 25352)
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4113 (class 2606 OID 26058)
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- TOC entry 4114 (class 2606 OID 26072)
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- TOC entry 4068 (class 2606 OID 25072)
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- TOC entry 4054 (class 2606 OID 24942)
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- TOC entry 4087 (class 2606 OID 25424)
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- TOC entry 4094 (class 2606 OID 25601)
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- TOC entry 4067 (class 2606 OID 25052)
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- TOC entry 4034 (class 2606 OID 16440)
-- Name: legal_documents legal_documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_documents
    ADD CONSTRAINT legal_documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.legal_users(id);


--
-- TOC entry 4035 (class 2606 OID 16435)
-- Name: legal_documents legal_documents_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_documents
    ADD CONSTRAINT legal_documents_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES public.legal_matters(id);


--
-- TOC entry 4032 (class 2606 OID 16412)
-- Name: legal_matters legal_matters_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_matters
    ADD CONSTRAINT legal_matters_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.legal_users(id);


--
-- TOC entry 4033 (class 2606 OID 16417)
-- Name: legal_matters legal_matters_responsible_attorney_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_matters
    ADD CONSTRAINT legal_matters_responsible_attorney_fkey FOREIGN KEY (responsible_attorney) REFERENCES public.legal_users(id);


--
-- TOC entry 4036 (class 2606 OID 16462)
-- Name: legal_recordings legal_recordings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_recordings
    ADD CONSTRAINT legal_recordings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.legal_users(id);


--
-- TOC entry 4037 (class 2606 OID 16457)
-- Name: legal_recordings legal_recordings_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_recordings
    ADD CONSTRAINT legal_recordings_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES public.legal_matters(id);


--
-- TOC entry 4038 (class 2606 OID 16479)
-- Name: legal_transcriptions legal_transcriptions_recording_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Verdict360
--

ALTER TABLE ONLY public.legal_transcriptions
    ADD CONSTRAINT legal_transcriptions_recording_id_fkey FOREIGN KEY (recording_id) REFERENCES public.legal_recordings(id);


-- Completed on 2025-05-23 13:04:11 UTC

--
-- PostgreSQL database dump complete
--

